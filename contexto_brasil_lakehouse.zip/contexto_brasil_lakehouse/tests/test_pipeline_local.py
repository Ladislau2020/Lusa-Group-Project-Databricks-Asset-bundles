"""Teste local do pipeline declarativo (bronze → silver → gold) com Spark open source.

Simula o runtime do Lakeflow: Auto Loader vira leitura batch de JSON, AUTO CDC vira deduplicação
pela chave (fica o registo com maior sequence_by) e as expectations `expect_or_drop` filtram linhas.
Serve para apanhar erros de SQL, de tipos e de lógica sem precisar de um workspace.

    python -m pytest tests/test_pipeline_local.py -q -s      (precisa de Java e pyspark>=4.0)
"""
import json
import pathlib
import sys
import tempfile
import types

import pytest

pyspark = pytest.importorskip("pyspark")
from pyspark.sql import SparkSession, Window  # noqa: E402
from pyspark.sql import functions as F  # noqa: E402

RAIZ = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ / "tests"))
from test_parsers import C  # noqa: E402  (funções da ingestão)

REGISTO = []          # ordem de declaração dos datasets
EXPECTATIVAS = {}     # nome do dataset -> lista de (tipo, nome, condição)
RELATORIO = {}


# ----------------------------------------------------------------- mock de pyspark.pipelines
def _expect(tipo):
    def deco_fab(nome, condicao):
        def deco(fn):
            fn.__dict__.setdefault("_exp", []).append((tipo, nome, condicao))
            return fn
        return deco
    return deco_fab


dp = types.ModuleType("pyspark.pipelines")
dp.expect = _expect("warn")
dp.expect_or_drop = _expect("drop")
dp.expect_or_fail = _expect("fail")


def _dataset(tipo):
    def fab(name=None, **_):
        def deco(fn):
            REGISTO.append((tipo, name or fn.__name__, fn))
            return fn
        return deco
    return fab


dp.table = _dataset("tabela")
dp.materialized_view = _dataset("mv")
dp.temporary_view = _dataset("view")
dp.create_streaming_table = lambda name, **_: None


def _cdc(target, source, keys, sequence_by, stored_as_scd_type=1, **_):
    REGISTO.append(("cdc", target, (source, keys, sequence_by, int(stored_as_scd_type))))


dp.create_auto_cdc_flow = _cdc
sys.modules["pyspark.pipelines"] = dp
pyspark.pipelines = dp


# ----------------------------------------------------------------- shim do spark (Auto Loader -> batch)
class LeitorStream:
    def __init__(self, spark):
        self.spark, self.opts, self._schema = spark, {}, None

    def format(self, _):
        return self

    def option(self, k, v):
        if not k.startswith("cloudFiles."):
            self.opts[k] = v
        return self

    def schema(self, s):
        self._schema = s
        return self

    def load(self, caminho):
        return (self.spark.read.format("json").schema(self._schema).options(**self.opts)
                .option("recursiveFileLookup", "true").load(caminho))

    def table(self, nome):
        return self.spark.table(nome)


class SparkShim:
    def __init__(self, spark):
        self._spark = spark

    @property
    def readStream(self):
        return LeitorStream(self._spark)

    def __getattr__(self, item):
        return getattr(self._spark, item)


# ----------------------------------------------------------------- dados de exemplo (formato real das APIs)
def amostras():
    sgs = [{"data": "01/08/2026", "valor": "-0.32"}, {"data": "01/09/2026", "valor": "0.82"},
           {"data": "01/10/2026", "valor": "0.40"}]
    ptax = [
        {"paridadeCompra": 1.0, "paridadeVenda": 1.0, "cotacaoCompra": 5.3101, "cotacaoVenda": 5.3107,
         "dataHoraCotacao": "2026-10-29 10:08:22.39", "tipoBoletim": "Abertura"},
        {"paridadeCompra": 1.0, "paridadeVenda": 1.0, "cotacaoCompra": 5.3201, "cotacaoVenda": 5.3207,
         "dataHoraCotacao": "2026-10-29 13:05:31.123", "tipoBoletim": "Fechamento PTAX"},
        {"paridadeCompra": 1.0, "paridadeVenda": 1.0, "cotacaoCompra": 5.3301, "cotacaoVenda": 5.3307,
         "dataHoraCotacao": "2026-10-30 13:04:11.5", "tipoBoletim": "Fechamento PTAX"},
    ]
    ptax_eur = [{"paridadeCompra": 1.0812, "paridadeVenda": 1.0813, "cotacaoCompra": 6.2001,
                 "cotacaoVenda": 6.2031, "dataHoraCotacao": "2026-10-30 13:04:11.5", "tipoBoletim": "Fechamento PTAX"}]
    moedas = [{"simbolo": "EUR", "nomeFormatado": "Euro", "tipoMoeda": "B"},
              {"simbolo": "JPY", "nomeFormatado": "Iene", "tipoMoeda": "A"}]
    bce = C.parse_csv_sdmx(
        "KEY,FREQ,CURRENCY,CURRENCY_DENOM,EXR_TYPE,EXR_SUFFIX,TIME_PERIOD,OBS_VALUE,OBS_STATUS,TITLE\n"
        "EXR.D.BRL.EUR.SP00.A,D,BRL,EUR,SP00,A,2026-10-29,6.10,A,Brazilian real/Euro\n"
        "EXR.D.BRL.EUR.SP00.A,D,BRL,EUR,SP00,A,2026-10-30,6.20,A,Brazilian real/Euro\n"
        "EXR.D.USD.EUR.SP00.A,D,USD,EUR,SP00,A,2026-10-30,1.1650,A,US dollar/Euro\n")
    brasilapi = [{"date": "2026-11-02", "name": "Finados", "type": "national"},
                 {"date": "2026-11-20", "name": "Dia Nacional de Zumbi e da Consciência Negra", "type": "national"}]
    nager = [{"date": "2026-11-02", "localName": "Finados", "name": "All Souls' Day", "countryCode": "BR",
              "fixed": True, "global": True, "counties": None, "launchYear": None, "types": ["Public"]},
             {"date": "2026-07-09", "localName": "Revolução Constitucionalista", "name": "Constitutionalist Revolution",
              "countryCode": "BR", "fixed": True, "global": False, "counties": ["BR-SP"], "launchYear": None,
              "types": ["Public"]}]
    uf_sp = {"id": 35, "sigla": "SP", "nome": "São Paulo", "regiao": {"id": 3, "sigla": "SE", "nome": "Sudeste"}}
    municipios = [{
        "id": 3550308, "nome": "São Paulo",
        "microrregiao": {"id": 35061, "nome": "São Paulo", "mesorregiao": {"id": 3515, "nome": "Metropolitana de São Paulo", "UF": uf_sp}},
        "regiao-imediata": {"id": 350001, "nome": "São Paulo",
                            "regiao-intermediaria": {"id": 3501, "nome": "São Paulo", "UF": uf_sp}},
    }, {  # município novo sem microrregião (acontece na API)
        "id": 3599999, "nome": "Município Novo", "microrregiao": None,
        "regiao-imediata": {"id": 350002, "nome": "X", "regiao-intermediaria": {"id": 3502, "nome": "Y", "UF": uf_sp}},
    }]
    pop = C.ibge_agregado_para_linhas([{
        "id": "9324", "variavel": "População residente estimada", "unidade": "Pessoas",
        "resultados": [{"classificacoes": [], "series": [
            {"localidade": {"id": "3550308", "nivel": {"id": "N6", "nome": "Município"}, "nome": "São Paulo - SP"},
             "serie": {"2024": "11895578", "2025": "11904961"}},
            {"localidade": {"id": "3599999", "nivel": {"id": "N6", "nome": "Município"}, "nome": "Novo - SP"},
             "serie": {"2025": "..."}}]}]}], 6579)
    censo = C.ibge_agregado_para_linhas([{
        "id": "93", "variavel": "População residente", "unidade": "Pessoas",
        "resultados": [{"classificacoes": [], "series": [
            {"localidade": {"id": "3550308", "nivel": {"id": "N6", "nome": "Município"}, "nome": "São Paulo - SP"},
             "serie": {"2022": "11451999"}}]}]}], 4709)
    estados = [uf_sp]
    meteo_resp = {
        "latitude": -23.5, "longitude": -46.625, "elevation": 760.0, "timezone": "America/Sao_Paulo",
        "timezone_abbreviation": "GMT-3", "utc_offset_seconds": -10800,
        "daily_units": {"time": "iso8601", "temperature_2m_max": "°C"},
        "daily": {"time": ["2026-10-25", "2026-10-26"], "weather_code": [61, 3],
                  "temperature_2m_max": [24.0, 31.2], "temperature_2m_min": [16.0, 18.5],
                  "precipitation_sum": [12.4, 0.0], "sunrise": ["2026-10-25T05:31", "2026-10-26T05:30"],
                  "sunset": ["2026-10-25T18:20", "2026-10-26T18:21"], "sunshine_duration": [3600.0, 36000.0],
                  "daylight_duration": [46000.0, 46100.0]},
        "hourly": {"time": ["2026-10-25T00:00", "2026-10-25T01:00"], "temperature_2m": [17.1, 16.8],
                   "relative_humidity_2m": [88, 90], "weather_code": [3, 61], "is_day": [0, 0]},
    }
    previsao_resp = {
        **{k: meteo_resp[k] for k in ("latitude", "longitude", "elevation", "timezone", "timezone_abbreviation",
                                      "utc_offset_seconds")},
        "daily": {"time": ["2026-10-26", "2026-10-30", "2026-11-04"], "weather_code": [2, 80, 95],
                  "temperature_2m_max": [30.0, 27.0, 33.0], "temperature_2m_min": [18.0, 19.0, 21.0],
                  "precipitation_sum": [0.0, 5.0, 40.0], "uv_index_max": [9.1, 7.0, 10.2],
                  "precipitation_probability_max": [5, 70, 90]},
        "hourly": {"time": ["2026-11-04T15:00"], "temperature_2m": [32.0], "precipitation_probability": [80]},
        "current": {"time": "2026-11-03T18:00", "interval": 900, "temperature_2m": 25.5, "weather_code": 2,
                    "is_day": 1, "relative_humidity_2m": 60},
    }
    locais = [{"cod_municipio": "3550308", "municipio": "São Paulo", "sigla_uf": "SP", "latitude": -23.567,
               "longitude": -46.570, "area_km2": 1521.2, "fonte_coordenadas": "ibge_malhas"}]
    ctx_meteo = {"cod_municipio": "3550308", "municipio": "São Paulo", "sigla_uf": "SP", "modelo": "x"}
    return [
        ("bcb", "sgs", sgs, {"serie_codigo": 433, "serie_nome": "IPCA", "categoria": "inflacao",
                             "unidade": "% a.m.", "periodicidade": "mensal"}),
        # sobreposição: o mesmo mês volta a chegar revisto numa carga posterior
        ("bcb", "sgs", [{"data": "01/10/2026", "valor": "0.45"}], {"serie_codigo": 433, "serie_nome": "IPCA",
                       "categoria": "inflacao", "unidade": "% a.m.", "periodicidade": "mensal"}),
        ("bcb", "ptax_cotacoes", ptax, {"moeda": "USD"}),
        ("bcb", "ptax_cotacoes", ptax_eur, {"moeda": "EUR"}),
        ("bcb", "ptax_moedas", moedas, None),
        ("bce", "exr", bce, None),
        ("feriados", "brasilapi", brasilapi, {"ano": 2026}),
        ("feriados", "nager", nager, {"ano": 2026}),
        ("ibge", "municipios", municipios, None),
        ("ibge", "estados", estados, None),
        ("ibge", "populacao_estimada", pop, None),
        ("ibge", "censo_2022", censo, None),
        ("meteo", "locais", locais, None),
        ("meteo", "unidades", C.open_meteo_unidades(meteo_resp, "archive"), None),
        ("meteo", "arquivo_diario", C.open_meteo_bloco_para_linhas(meteo_resp, "daily"), ctx_meteo),
        ("meteo", "arquivo_horario", C.open_meteo_bloco_para_linhas(meteo_resp, "hourly"), ctx_meteo),
        ("meteo", "previsao_diaria", C.open_meteo_bloco_para_linhas(previsao_resp, "daily"), ctx_meteo),
        ("meteo", "previsao_horaria", C.open_meteo_bloco_para_linhas(previsao_resp, "hourly"), ctx_meteo),
        ("meteo", "atual", [C.open_meteo_atual_para_linha(previsao_resp)], ctx_meteo),
    ]


# ----------------------------------------------------------------- execução
@pytest.fixture(scope="module")
def resultado():
    tmp = pathlib.Path(tempfile.mkdtemp())
    C.LANDING = str(tmp / "landing")
    import time as _t
    for fonte, dataset, registos, ctx in amostras():
        C.gravar_landing(fonte, dataset, registos, f"https://exemplo/{fonte}/{dataset}", ctx)
        _t.sleep(0.01)  # garante _ingestao_ts diferentes entre cargas

    spark = (SparkSession.builder.master("local[2]").appName("teste-pipeline")
             .config("spark.sql.warehouse.dir", str(tmp / "warehouse"))
             .config("spark.sql.shuffle.partitions", "2")
             .config("spark.sql.session.timeZone", "UTC")
             .config("spark.ui.enabled", "false").getOrCreate())
    for esquema in ("bronze", "silver", "gold"):
        spark.sql(f"CREATE DATABASE IF NOT EXISTS {esquema}")
    spark.conf.set("contexto.catalog", "spark_catalog")
    spark.conf.set("contexto.landing", C.LANDING)
    shim = SparkShim(spark)

    for f in ["bronze", "silver_financeiro", "silver_territorio", "silver_meteo", "gold"]:
        codigo = (RAIZ / f"src/pipeline/{f}.py").read_text(encoding="utf-8")
        exec(compile(codigo, f"{f}.py", "exec"), {"spark": shim, "__name__": f})

    views = {}
    for tipo, nome, obj in REGISTO:
        if tipo == "view":
            df = obj()
            for t, n, cond in getattr(obj, "_exp", []):
                falham = df.filter(f"NOT coalesce(({cond}), false)").count()
                RELATORIO[f"{nome}:{n}"] = falham
                if t == "drop":
                    df = df.filter(f"coalesce(({cond}), false)")
            views[nome] = df
        elif tipo == "cdc":
            fonte, chaves, seq, scd = obj
            df = views[fonte].withColumn("__seq", seq)
            w = Window.partitionBy(*chaves).orderBy(F.col("__seq").desc())
            df = df.withColumn("__rn", F.row_number().over(w)).filter("__rn = 1").drop("__rn")
            if scd == 2:
                df = (df.withColumn("__START_AT", F.col("__seq"))
                        .withColumn("__END_AT", F.lit(None).cast(df.schema["__seq"].dataType)))
            df.drop("__seq").write.mode("overwrite").saveAsTable(nome)
        else:  # tabela bronze ou materialized view
            obj().write.mode("overwrite").saveAsTable(nome)
    yield spark
    spark.stop()


def t(spark, nome):
    return spark.table(f"spark_catalog.{nome}")


def test_bronze_guarda_envelope(resultado):
    b = t(resultado, "bronze.bcb_sgs")
    assert b.count() == 4
    assert {"payload", "contexto", "ingestao_ts", "ficheiro"} <= set(b.columns)


def test_silver_sgs_deduplica_e_fica_com_revisao(resultado):
    s = t(resultado, "silver.bcb_sgs")
    assert s.count() == 3
    out = s.filter("data = DATE'2026-10-01'").first()
    assert out.valor == 0.45 and out.serie_nome == "IPCA" and out.serie_codigo == 433


def test_silver_ptax(resultado):
    s = t(resultado, "silver.bcb_ptax_cotacoes")
    assert s.count() == 4
    r = s.filter("moeda = 'USD' AND tipo_boletim = 'Abertura'").first()
    assert str(r.data_hora_cotacao) == "2026-10-29 10:08:22.390000" and r.e_fechamento is False
    assert abs(r.spread - 0.0006) < 1e-9


def test_silver_bce_e_feriados(resultado):
    b = t(resultado, "silver.bce_exr").filter("moeda = 'BRL' AND data = DATE'2026-10-30'").first()
    assert b.taxa_por_eur == 6.20 and b.title == "Brazilian real/Euro" and b.obs_status == "A"
    n = t(resultado, "silver.feriados_nager").filter("nome_en = 'Constitutionalist Revolution'").first()
    assert n.ufs == ["SP"] and n.nacional is False and n.tipos == ["Public"]


def test_silver_ibge(resultado):
    m = t(resultado, "silver.ibge_municipios")
    assert m.count() == 2
    novo = m.filter("cod_municipio = 3599999").first()
    assert novo.sigla_uf == "SP" and novo.microrregiao is None and novo.regiao == "Sudeste"
    p = t(resultado, "silver.ibge_populacao_estimada")
    assert p.filter("cod_municipio = 3550308 AND ano = 2025").first().populacao == 11904961
    assert p.filter("cod_municipio = 3599999").first().populacao is None  # '...' do SIDRA
    assert RELATORIO["v_ibge_populacao_estimada:populacao_publicada"] == 1


def test_silver_meteo(resultado):
    d = t(resultado, "silver.meteo_arquivo_diario").filter("data = DATE'2026-10-25'").first()
    assert d.temperature_2m_max == 24.0 and d.weather_code == 61 and d.cod_municipio == 3550308
    assert str(d.sunrise) == "2026-10-25 05:31:00" and d.amplitude_termica == 8.0
    h = t(resultado, "silver.meteo_arquivo_horario").filter("hora = 1").first()
    assert h.relative_humidity_2m == 90.0 and h.weather_code == 61
    a = t(resultado, "silver.meteo_atual").first()
    assert a.temperature_2m == 25.5 and a.interval == 900


def test_gold_calendario(resultado):
    c = t(resultado, "gold.dim_calendario")
    finados = c.filter("data = DATE'2026-11-02'").first()
    assert finados.e_feriado_nacional and not finados.e_dia_util and finados.nome_dia_semana == "segunda-feira"
    assert c.filter("data = DATE'2026-07-09'").first().ufs_feriado_regional == ["SP"]
    nov = c.filter("ano_mes = '2026-11'").first()
    assert nov.dias_uteis_no_mes == 19  # 21 dias úteis em nov/2026 menos Finados e Consciência Negra
    assert c.filter("data = DATE'2026-01-15'").first().estacao_ano == "verão"
    assert "ontem_util" not in c.columns


def test_gold_cambio(resultado):
    f = t(resultado, "gold.fato_cambio_ptax_diario")
    usd = f.filter("moeda = 'USD'").orderBy("data").collect()
    assert len(usd) == 2 and usd[0].ptax_venda == 5.3207 and usd[0].boletins_no_dia == 2
    assert abs(usd[1].variacao_dia_pct - (5.3307 / 5.3207 - 1) * 100) < 1e-9
    assert abs(usd[1].bce_brl_por_unidade - 6.20 / 1.1650) < 1e-9
    eur = f.filter("moeda = 'EUR'").first()
    assert eur.bce_brl_por_unidade == 6.20 and eur.moeda_nome == "Euro"
    e = t(resultado, "gold.fato_cambio_eur_diario").filter("moeda = 'USD'").first()
    assert abs(e.brl_por_unidade_cruzado - 6.20 / 1.1650) < 1e-9


def test_gold_indicadores(resultado):
    g = t(resultado, "gold.fato_indicadores_mensal").filter("ano_mes = '2026-10'").first()
    esperado = ((1 - 0.0032) * (1 + 0.0082) * (1 + 0.0045) - 1) * 100
    assert abs(g.acumulado_ano_pct - esperado) < 1e-9 and g.acumulado_12m_pct is None


def test_gold_municipio_e_meteo(resultado):
    m = t(resultado, "gold.dim_municipio").filter("cod_municipio = 3550308").first()
    assert m.e_capital and m.populacao_estimada == 11904961 and m.populacao_censo_2022 == 11451999
    assert m.tem_meteorologia and abs(m.densidade_hab_km2 - 11904961 / 1521.2) < 1e-6
    md = t(resultado, "gold.fato_meteo_diario")
    assert md.count() == 4  # 2 do arquivo + 2 da previsão (26/10 vem do arquivo)
    dia26 = md.filter("data = DATE'2026-10-26'").first()
    assert dia26.origem == "arquivo" and dia26.tipo_registo == "histórico" and dia26.condicao == "Nublado"
    futuro = md.filter("data = DATE'2026-11-04'").first()
    assert futuro.classe_chuva == "chuva forte" and futuro.uv_index_max == 10.2 and futuro.grupo_condicao == "trovoada"
    atual = t(resultado, "gold.meteo_condicao_atual").first()
    assert atual.condicao == "Parcialmente nublado" and atual.e_dia is True


def test_relatorio(resultado):
    print("\nExpectations (linhas que falham):", json.dumps(RELATORIO, indent=1, ensure_ascii=False))
