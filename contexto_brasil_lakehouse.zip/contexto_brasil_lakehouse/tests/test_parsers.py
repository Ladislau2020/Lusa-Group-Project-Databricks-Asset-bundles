"""Testes das funções puras de ingestão (correm fora do Databricks).

    python -m pytest tests/ -q
"""
import datetime as dt
import json
import pathlib
import types

RAIZ = pathlib.Path(__file__).resolve().parents[1]


def carregar_comum():
    codigo = (RAIZ / "src/ingestion/_comum.py").read_text(encoding="utf-8")
    codigo = "\n".join(l for l in codigo.splitlines() if not l.startswith("# MAGIC"))
    mod = types.ModuleType("_comum")
    exec(compile(codigo, "_comum.py", "exec"), mod.__dict__)
    return mod


C = carregar_comum()


def test_bcb_data():
    assert C.bcb_data_para_iso("01/09/2026") == "2026-09-01"


def test_blocos_de_datas_respeitam_limite():
    blocos = list(C.blocos_de_datas("2016-01-01", "2026-11-03", 3650))
    assert blocos[0][0] == dt.date(2016, 1, 1)
    assert blocos[-1][1] == dt.date(2026, 11, 3)
    assert all((b - a).days < 3650 for a, b in blocos)
    for (a1, b1), (a2, _) in zip(blocos, blocos[1:]):
        assert a2 == b1 + dt.timedelta(days=1)


def test_url_ptax():
    url = C.ptax_url_cotacoes("EUR", "2026-10-01", "2026-10-31")
    assert "@moeda='EUR'" in url
    assert "@dataInicial='10-01-2026'" in url
    assert "@dataFinalCotacao='10-31-2026'" in url
    assert url.endswith("$format=json")


def test_csv_sdmx_guarda_todas_as_colunas():
    texto = ("KEY,FREQ,CURRENCY,CURRENCY_DENOM,EXR_TYPE,EXR_SUFFIX,TIME_PERIOD,OBS_VALUE,OBS_STATUS,TITLE\n"
             "EXR.D.BRL.EUR.SP00.A,D,BRL,EUR,SP00,A,2026-10-30,6.2345,A,Brazilian real/Euro\n"
             "EXR.D.USD.EUR.SP00.A,D,USD,EUR,SP00,A,2026-10-30,1.0812,A,\n")
    linhas = C.parse_csv_sdmx(texto)
    assert len(linhas) == 2
    assert linhas[0]["OBS_VALUE"] == "6.2345" and linhas[0]["TITLE"] == "Brazilian real/Euro"
    assert linhas[1]["TITLE"] is None


def test_ibge_agregado():
    resposta = [{
        "id": "9324", "variavel": "População residente estimada", "unidade": "Pessoas",
        "resultados": [{"classificacoes": [], "series": [
            {"localidade": {"id": "3550308", "nivel": {"id": "N6", "nome": "Município"}, "nome": "São Paulo - SP"},
             "serie": {"2024": "11895578", "2025": "11904961"}},
            {"localidade": {"id": "4205407", "nivel": {"id": "N6", "nome": "Município"}, "nome": "Florianópolis - SC"},
             "serie": {"2024": "-"}},
        ]}],
    }]
    linhas = C.ibge_agregado_para_linhas(resposta, 6579)
    assert len(linhas) == 3
    sp = [l for l in linhas if l["localidade_id"] == "3550308" and l["periodo"] == "2025"][0]
    assert sp["valor"] == "11904961" and sp["agregado"] == "6579" and sp["nivel_id"] == "N6"


def test_open_meteo_bloco_e_unidades():
    resp = {
        "latitude": -23.5, "longitude": -46.625, "elevation": 760.0, "timezone": "America/Sao_Paulo",
        "timezone_abbreviation": "GMT-3", "utc_offset_seconds": -10800,
        "daily_units": {"time": "iso8601", "temperature_2m_max": "°C"},
        "daily": {"time": ["2024-01-01", "2024-01-02"], "temperature_2m_max": [29.1, None],
                  "sunrise": ["2024-01-01T05:20", "2024-01-02T05:21"]},
        "current": {"time": "2026-11-03T14:00", "interval": 900, "temperature_2m": 24.3},
    }
    linhas = C.open_meteo_bloco_para_linhas(resp, "daily")
    assert len(linhas) == 2
    assert linhas[0]["time"] == "2024-01-01" and linhas[0]["temperature_2m_max"] == 29.1
    assert linhas[1]["temperature_2m_max"] is None
    assert linhas[0]["utc_offset_segundos"] == -10800 and linhas[0]["elevacao"] == 760.0
    assert C.open_meteo_bloco_para_linhas(resp, "hourly") == []
    assert C.open_meteo_atual_para_linha(resp)["temperature_2m"] == 24.3
    unidades = C.open_meteo_unidades(resp, "archive")
    assert {"endpoint": "archive", "bloco": "daily", "variavel": "temperature_2m_max", "unidade": "°C"} in unidades
    assert C.open_meteo_como_lista(resp) == [resp]
    assert C.open_meteo_como_lista([resp, resp]) == [resp, resp]


def test_variavel_invalida():
    erro = ('{"error":true,"reason":"Data corrupted at path \'\'. Cannot initialize ForecastVariableDaily '
            'from invalid String value temperature_2m_maxx."}')
    assert C.variavel_invalida_open_meteo(erro, ["temperature_2m", "temperature_2m_maxx"]) == "temperature_2m_maxx"
    assert C.variavel_invalida_open_meteo("outro erro", ["temperature_2m"]) is None


def test_envelope():
    ts = dt.datetime(2026, 11, 3, 21, 9, 0, 123456, tzinfo=dt.timezone.utc)
    linhas = C.montar_linhas("bcb", "sgs", [{"data": "01/09/2026", "valor": "0.82"}], "http://x",
                             {"serie_codigo": 433}, ts)
    l = linhas[0]
    assert l["_ingestao_ts"] == "2026-11-03 21:09:00.123456"
    assert l["contexto"] == {"serie_codigo": "433"} and l["_linha"] == 0
    assert json.loads(l["payload"]) == {"data": "01/09/2026", "valor": "0.82"}
    assert set(l) == {"_fonte", "_dataset", "_url", "_ingestao_ts", "_lote_id", "_linha", "contexto", "payload"}
