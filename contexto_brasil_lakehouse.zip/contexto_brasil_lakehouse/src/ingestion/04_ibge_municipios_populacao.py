# Databricks notebook source
# MAGIC %md
# MAGIC # 04 · IBGE — municípios, estados e população
# MAGIC
# MAGIC API de Serviços de Dados do IBGE (`servicodados.ibge.gov.br`), sem autenticação.
# MAGIC
# MAGIC | Dataset | Endpoint | Conteúdo |
# MAGIC |---|---|---|
# MAGIC | `municipios` | `/api/v1/localidades/municipios` | os 5.570 municípios com toda a hierarquia: microrregião, mesorregião, região imediata, região intermediária, UF e grande região |
# MAGIC | `estados` | `/api/v1/localidades/estados` | UFs e grandes regiões |
# MAGIC | `populacao_estimada` | `/api/v3/agregados/6579/...` | estimativas anuais da população residente por município (tabela SIDRA 6579) |
# MAGIC | `censo_2022` | `/api/v3/agregados/4709/...` | população residente no Censo 2022 (tabela SIDRA 4709) |
# MAGIC
# MAGIC Estes dados mudam no máximo uma vez por ano, por isso o notebook só volta a pedir passados
# MAGIC `dias_entre_cargas` dias. A silver guarda o histórico de alterações dos municípios (SCD tipo 2).

# COMMAND ----------

# MAGIC %run ./_comum

# COMMAND ----------

dbutils.widgets.text("catalog", "dev_contexto_br", "Catálogo")
dbutils.widgets.text("dias_entre_cargas", "7", "Dias entre cargas")
dbutils.widgets.dropdown("forcar_recarga", "nao", ["nao", "sim"], "Forçar carga")

configurar(dbutils.widgets.get("catalog"))
HORAS = int(dbutils.widgets.get("dias_entre_cargas")) * 24
FORCAR = dbutils.widgets.get("forcar_recarga") == "sim"

BASE = "https://servicodados.ibge.gov.br/api"

# COMMAND ----------

falhas = []


def carregar(dataset, url, params=None, transformar=None, obrigatorio=True):
    if not precisa_refrescar(spark, "ibge", dataset, HORAS, FORCAR):
        print(f"{dataset}: carregado há menos de {HORAS // 24} dias, ignorado.")
        return
    try:
        print(f"{dataset}: a pedir {url}")
        resposta = http_get(url, params, timeout=300).json()
        registos = transformar(resposta) if transformar else resposta
        gravar_landing("ibge", dataset, registos, url_final(url, params))
        gravar_controlo(spark, "ibge", dataset, str(len(registos)))
    except Exception as e:
        print(f"  ✗ {dataset}: {e}")
        if obrigatorio:
            falhas.append(dataset)


carregar("municipios", f"{BASE}/v1/localidades/municipios")
carregar("estados", f"{BASE}/v1/localidades/estados")

carregar(
    "populacao_estimada",
    f"{BASE}/v3/agregados/6579/periodos/all/variaveis/9324",
    params={"localidades": "N6[all]"},
    transformar=lambda resp: ibge_agregado_para_linhas(resp, 6579),
)

# Censo 2022: complementa as estimativas com a contagem censitária
carregar(
    "censo_2022",
    f"{BASE}/v3/agregados/4709/periodos/2022/variaveis/93",
    params={"localidades": "N6[all]"},
    transformar=lambda resp: ibge_agregado_para_linhas(resp, 4709),
    obrigatorio=False,
)

# COMMAND ----------

if falhas:
    raise RuntimeError(f"IBGE com falha: {falhas}")
print("IBGE concluído.")
