# Databricks notebook source
# MAGIC %md
# MAGIC # 02 · Banco Central Europeu — taxas de referência do euro
# MAGIC
# MAGIC Fonte oficial (é também de onde vêm os dados da Frankfurter v1): API SDMX do BCE,
# MAGIC conjunto **EXR**, chave `D..EUR.SP00.A` = diário, **todas as moedas**, contra EUR,
# MAGIC taxa de referência *spot*, média.
# MAGIC
# MAGIC O formato `csvdata` traz cada observação com **todos os atributos** da série
# MAGIC (título, unidade, multiplicador, casas decimais, estado da observação, organismo, etc.).
# MAGIC Tudo isso é guardado no bronze.
# MAGIC
# MAGIC As taxas do BCE são publicadas em dias úteis TARGET, por volta das 16:00 CET.

# COMMAND ----------

# MAGIC %run ./_comum

# COMMAND ----------

dbutils.widgets.text("catalog", "dev_contexto_br", "Catálogo")
dbutils.widgets.text("data_inicio", "2016-01-01", "Data inicial do histórico")
dbutils.widgets.dropdown("forcar_recarga", "nao", ["nao", "sim"], "Ignorar watermarks")

configurar(dbutils.widgets.get("catalog"))
DATA_INICIO = para_data(dbutils.widgets.get("data_inicio"))
FORCAR = dbutils.widgets.get("forcar_recarga") == "sim"
HOJE = dt.date.today()

URL_EXR = "https://data-api.ecb.europa.eu/service/data/EXR/D..EUR.SP00.A"

# COMMAND ----------

marca = None if FORCAR else ler_controlo(spark, "bce_exr", "D..EUR.SP00.A")
inicio = DATA_INICIO if marca is None else max(DATA_INICIO, para_data(marca) - dt.timedelta(days=10))
print(f"BCE EXR · de {inicio} a {HOJE}")

maior_data = marca
for de, ate in blocos_de_datas(inicio, HOJE, 366):
    params = {"format": "csvdata", "startPeriod": de.isoformat(), "endPeriod": ate.isoformat()}
    r = http_get(URL_EXR, params, aceitar_404=True)  # 404 = sem observações no período
    if r is None or not r.text.strip():
        continue
    registos = parse_csv_sdmx(r.text)
    gravar_landing("bce", "exr", registos, url_final(URL_EXR, params), contexto={"chave_sdmx": "D..EUR.SP00.A"})
    if registos:
        ultima = max(x["TIME_PERIOD"] for x in registos if x.get("TIME_PERIOD"))
        maior_data = ultima if maior_data is None else max(maior_data, ultima)
    time.sleep(1)

if maior_data:
    gravar_controlo(spark, "bce_exr", "D..EUR.SP00.A", maior_data)
print("BCE concluído. Última data:", maior_data)
