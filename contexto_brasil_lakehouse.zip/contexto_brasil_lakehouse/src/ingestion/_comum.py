# Databricks notebook source
# MAGIC %md
# MAGIC # Funções comuns de ingestão
# MAGIC
# MAGIC Usado com `%run ./_comum` pelos notebooks `01`–`05`.
# MAGIC
# MAGIC **Contrato da landing zone** (o que o pipeline declarativo espera ler):
# MAGIC
# MAGIC `/Volumes/<catalog>/ops/landing/<fonte>/<dataset>/AAAA/MM/DD/<timestamp>_<id>.json`
# MAGIC
# MAGIC Cada linha do ficheiro (JSON Lines) é um registo bruto da API dentro de um envelope:
# MAGIC
# MAGIC | campo | descrição |
# MAGIC |---|---|
# MAGIC | `_fonte`, `_dataset` | origem lógica (ex.: `bcb` / `sgs`) |
# MAGIC | `_url` | pedido HTTP exato que gerou o registo |
# MAGIC | `_ingestao_ts` | instante UTC da escrita do ficheiro |
# MAGIC | `_lote_id` | id da execução do notebook |
# MAGIC | `_linha` | posição do registo no ficheiro (desempate na deduplicação) |
# MAGIC | `contexto` | metadados do pedido (ex.: código da série, município) |
# MAGIC | `payload` | o registo da API, em texto JSON, sem alterações |

# COMMAND ----------

import csv
import io
import json
import os
import time
import uuid
import datetime as dt
from urllib.parse import quote

import requests

USER_AGENT = "contexto-brasil-lakehouse/1.0 (+databricks notebook)"
LOTE_ID = uuid.uuid4().hex

# Preenchidos por configurar()
CATALOGO = None
LANDING = None


def configurar(catalogo: str) -> dict:
    """Define o catálogo e o caminho da landing zone para este notebook."""
    global CATALOGO, LANDING
    CATALOGO = catalogo.strip()
    LANDING = f"/Volumes/{CATALOGO}/ops/landing"
    print(f"Catálogo: {CATALOGO} | Landing: {LANDING} | Lote: {LOTE_ID}")
    return {"catalogo": CATALOGO, "landing": LANDING, "lote_id": LOTE_ID}


# COMMAND ----------

# MAGIC %md ## HTTP com retries

# COMMAND ----------

class LimiteDiarioExcedido(Exception):
    """A API respondeu 429 de forma persistente (limite diário/horário atingido)."""


def http_get(url, params=None, timeout=120, tentativas=5, espera_base=5, aceitar_404=False):
    """GET com backoff exponencial para 429, 5xx e erros de rede.

    - 4xx (exceto 429) falha logo, porque repetir não resolve.
    - 404 devolve None quando aceitar_404=True (ex.: série do BCB sem dados no intervalo).
    - 429 persistente levanta LimiteDiarioExcedido, para o notebook parar com elegância
      e retomar na próxima execução a partir dos watermarks.
    """
    ultimo_erro = None
    for tentativa in range(tentativas):
        try:
            r = requests.get(
                url,
                params=params,
                timeout=timeout,
                headers={"User-Agent": USER_AGENT, "Accept": "application/json, text/csv;q=0.9, */*;q=0.5"},
            )
        except (requests.ConnectionError, requests.Timeout) as e:
            ultimo_erro = e
            status = None
        else:
            if r.status_code == 404 and aceitar_404:
                return None
            if r.status_code < 400:
                return r
            status = r.status_code
            ultimo_erro = requests.HTTPError(f"HTTP {status} em {r.url}: {r.text[:300]}", response=r)
            if 400 <= status < 500 and status != 429:
                raise ultimo_erro

        if tentativa == tentativas - 1:
            break
        pausa = espera_base * (2 ** tentativa) * (6 if status == 429 else 1)
        print(f"  ! tentativa {tentativa + 1}/{tentativas} falhou ({ultimo_erro}); nova tentativa em {pausa}s")
        time.sleep(pausa)

    if isinstance(ultimo_erro, requests.HTTPError) and ultimo_erro.response is not None \
            and ultimo_erro.response.status_code == 429:
        raise LimiteDiarioExcedido(str(ultimo_erro))
    raise ultimo_erro


def url_final(url, params=None):
    """URL completo (com query string) para registar no envelope."""
    if not params:
        return url
    return requests.Request("GET", url, params=params).prepare().url


# COMMAND ----------

# MAGIC %md ## Escrita na landing zone

# COMMAND ----------

def _agora_utc():
    return dt.datetime.now(dt.timezone.utc)


def montar_linhas(fonte, dataset, registos, url, contexto=None, ingestao_ts=None):
    """Converte registos da API em linhas-envelope (lista de dicts). Função pura, testável."""
    ingestao_ts = ingestao_ts or _agora_utc()
    ts_txt = ingestao_ts.strftime("%Y-%m-%d %H:%M:%S.%f")
    ctx = {str(k): (None if v is None else str(v)) for k, v in (contexto or {}).items()}
    linhas = []
    for i, reg in enumerate(registos):
        linhas.append({
            "_fonte": fonte,
            "_dataset": dataset,
            "_url": url,
            "_ingestao_ts": ts_txt,
            "_lote_id": LOTE_ID,
            "_linha": i,
            "contexto": ctx,
            "payload": json.dumps(reg, ensure_ascii=False, default=str),
        })
    return linhas


def gravar_landing(fonte, dataset, registos, url, contexto=None):
    """Grava um ficheiro JSON Lines na landing zone. Escreve primeiro .tmp e renomeia,
    para o Auto Loader nunca ler um ficheiro a meio (o bronze só lê *.json)."""
    registos = list(registos or [])
    if not registos:
        return None
    if LANDING is None:
        raise RuntimeError("Chame configurar(catalogo) antes de gravar.")
    agora = _agora_utc()
    pasta = f"{LANDING}/{fonte}/{dataset}/{agora:%Y/%m/%d}"
    os.makedirs(pasta, exist_ok=True)
    nome = f"{agora:%Y%m%dT%H%M%S%f}_{uuid.uuid4().hex[:8]}.json"
    destino = f"{pasta}/{nome}"
    tmp = destino + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        for linha in montar_linhas(fonte, dataset, registos, url, contexto, agora):
            f.write(json.dumps(linha, ensure_ascii=False) + "\n")
    os.replace(tmp, destino)
    print(f"  ✓ {len(registos):>7} registos → {fonte}/{dataset}/{nome}")
    return destino


# COMMAND ----------

# MAGIC %md ## Watermarks (tabela `ops.controlo_ingestao`)

# COMMAND ----------

def ler_controlo(spark, fonte, chave, defeito=None):
    """Lê o último valor guardado para (fonte, chave). Devolve `defeito` se não existir."""
    linhas = spark.sql(
        f"SELECT valor FROM {CATALOGO}.ops.controlo_ingestao WHERE fonte = :fonte AND chave = :chave",
        args={"fonte": fonte, "chave": chave},
    ).collect()
    return linhas[0]["valor"] if linhas and linhas[0]["valor"] is not None else defeito


def gravar_controlo(spark, fonte, chave, valor):
    spark.sql(
        f"""
        MERGE INTO {CATALOGO}.ops.controlo_ingestao t
        USING (SELECT :fonte AS fonte, :chave AS chave, :valor AS valor) s
        ON t.fonte = s.fonte AND t.chave = s.chave
        WHEN MATCHED THEN UPDATE SET t.valor = s.valor, t.atualizado_em = current_timestamp(), t.lote_id = :lote
        WHEN NOT MATCHED THEN INSERT (fonte, chave, valor, atualizado_em, lote_id)
             VALUES (s.fonte, s.chave, s.valor, current_timestamp(), :lote)
        """,
        args={"fonte": fonte, "chave": chave, "valor": None if valor is None else str(valor), "lote": LOTE_ID},
    )


def ultima_atualizacao(spark, fonte, chave):
    """Timestamp (UTC) da última gravação de (fonte, chave), ou None."""
    linhas = spark.sql(
        f"SELECT atualizado_em FROM {CATALOGO}.ops.controlo_ingestao WHERE fonte = :fonte AND chave = :chave",
        args={"fonte": fonte, "chave": chave},
    ).collect()
    return linhas[0]["atualizado_em"] if linhas else None


def precisa_refrescar(spark, fonte, chave, horas, forcar=False):
    """True se (fonte, chave) nunca correu ou correu há mais de `horas` horas."""
    if forcar:
        return True
    ultima = ultima_atualizacao(spark, fonte, chave)
    if ultima is None:
        return True
    if ultima.tzinfo is None:
        ultima = ultima.replace(tzinfo=dt.timezone.utc)
    return (_agora_utc() - ultima) >= dt.timedelta(hours=horas)


# COMMAND ----------

# MAGIC %md ## Utilitários de datas

# COMMAND ----------

def para_data(valor):
    if isinstance(valor, dt.date):
        return valor
    return dt.date.fromisoformat(str(valor)[:10])


def blocos_de_datas(inicio, fim, dias_por_bloco):
    """Divide [inicio, fim] em blocos contíguos de no máximo `dias_por_bloco` dias."""
    inicio, fim = para_data(inicio), para_data(fim)
    atual = inicio
    while atual <= fim:
        ate = min(atual + dt.timedelta(days=dias_por_bloco - 1), fim)
        yield atual, ate
        atual = ate + dt.timedelta(days=1)


# COMMAND ----------

# MAGIC %md ## Parsers por fonte (funções puras, cobertas por testes)

# COMMAND ----------

def bcb_data_para_iso(txt):
    """'31/12/2025' -> '2025-12-31'."""
    d, m, a = str(txt).split("/")
    return f"{a}-{int(m):02d}-{int(d):02d}"


def ptax_url_cotacoes(moeda, inicio, fim):
    """URL OData do PTAX (Olinda) com todas as colunas e todos os boletins do período.
    As datas do PTAX usam o formato MM-DD-AAAA."""
    inicio, fim = para_data(inicio), para_data(fim)
    base = ("https://olinda.bcb.gov.br/olinda/servico/PTAX/versao/v1/odata/"
            "CotacaoMoedaPeriodo(moeda=@moeda,dataInicial=@dataInicial,dataFinalCotacao=@dataFinalCotacao)")
    query = (f"@moeda='{quote(moeda)}'"
             f"&@dataInicial='{inicio:%m-%d-%Y}'"
             f"&@dataFinalCotacao='{fim:%m-%d-%Y}'"
             f"&$top=100000&$format=json")
    return f"{base}?{query}"


def parse_csv_sdmx(texto):
    """CSV SDMX do BCE -> lista de dicts com TODAS as colunas (atributos incluídos)."""
    leitor = csv.DictReader(io.StringIO(texto))
    return [{k: (v if v != "" else None) for k, v in linha.items()} for linha in leitor]


def ibge_agregado_para_linhas(resposta, agregado):
    """Resposta da API de agregados v3 (aninhada) -> uma linha por localidade x período x classificação."""
    linhas = []
    for variavel in resposta or []:
        for resultado in variavel.get("resultados", []):
            classificacoes = resultado.get("classificacoes") or []
            categorias = {
                c.get("nome"): ", ".join(str(v) for v in (c.get("categoria") or {}).values())
                for c in classificacoes
            }
            for serie in resultado.get("series", []):
                loc = serie.get("localidade") or {}
                nivel = loc.get("nivel") or {}
                for periodo, valor in (serie.get("serie") or {}).items():
                    linhas.append({
                        "agregado": str(agregado),
                        "variavel_id": variavel.get("id"),
                        "variavel": variavel.get("variavel"),
                        "unidade": variavel.get("unidade"),
                        "localidade_id": loc.get("id"),
                        "localidade_nome": loc.get("nome"),
                        "nivel_id": nivel.get("id"),
                        "nivel_nome": nivel.get("nome"),
                        "periodo": periodo,
                        "valor": valor,
                        "classificacoes": categorias or None,
                    })
    return linhas


def open_meteo_como_lista(resposta):
    """Pedidos com várias coordenadas devolvem uma lista; com uma só, um objeto."""
    if isinstance(resposta, list):
        return resposta
    return [resposta]


def open_meteo_bloco_para_linhas(local_resp, bloco):
    """Converte um bloco colunar ('hourly'/'daily'/'minutely_15') em linhas, uma por instante.

    Mantém todas as variáveis devolvidas e acrescenta os metadados do ponto da grelha."""
    dados = local_resp.get(bloco)
    if not dados:
        return []
    tempos = dados.get("time") or []
    variaveis = [k for k in dados.keys() if k != "time"]
    meta = {
        "grelha_latitude": local_resp.get("latitude"),
        "grelha_longitude": local_resp.get("longitude"),
        "elevacao": local_resp.get("elevation"),
        "timezone": local_resp.get("timezone"),
        "timezone_abreviatura": local_resp.get("timezone_abbreviation"),
        "utc_offset_segundos": local_resp.get("utc_offset_seconds"),
    }
    linhas = []
    for i, t in enumerate(tempos):
        linha = {"time": t}
        for v in variaveis:
            serie = dados.get(v) or []
            linha[v] = serie[i] if i < len(serie) else None
        linha.update(meta)
        linhas.append(linha)
    return linhas


def open_meteo_atual_para_linha(local_resp):
    atual = local_resp.get("current")
    if not atual:
        return None
    linha = dict(atual)
    linha.update({
        "grelha_latitude": local_resp.get("latitude"),
        "grelha_longitude": local_resp.get("longitude"),
        "elevacao": local_resp.get("elevation"),
        "timezone": local_resp.get("timezone"),
        "utc_offset_segundos": local_resp.get("utc_offset_seconds"),
    })
    return linha


def open_meteo_unidades(resposta_local, endpoint):
    """Extrai as unidades (hourly_units, daily_units, current_units) em linhas."""
    linhas = []
    for chave, valor in resposta_local.items():
        if chave.endswith("_units") and isinstance(valor, dict):
            bloco = chave[: -len("_units")]
            for variavel, unidade in valor.items():
                linhas.append({"endpoint": endpoint, "bloco": bloco, "variavel": variavel, "unidade": unidade})
    return linhas


def variavel_invalida_open_meteo(texto_erro, variaveis):
    """Se a API recusar uma variável (HTTP 400), descobre qual, para a retirar e repetir o pedido."""
    for v in sorted(variaveis, key=len, reverse=True):
        if f"'{v}'" in texto_erro or f'"{v}"' in texto_erro or f" {v}" in texto_erro:
            return v
    return None
