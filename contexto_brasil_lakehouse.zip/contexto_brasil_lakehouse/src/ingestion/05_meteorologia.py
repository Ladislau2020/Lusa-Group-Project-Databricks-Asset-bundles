# Databricks notebook source
# MAGIC %md
# MAGIC # 05 · Meteorologia — histórico, observação recente e previsão (Open-Meteo)
# MAGIC
# MAGIC | Dataset | API | Para quê |
# MAGIC |---|---|---|
# MAGIC | `arquivo_diario` | `archive-api.open-meteo.com/v1/archive` | histórico diário (reanálise ERA5, desde 1940) |
# MAGIC | `arquivo_horario` | idem | histórico horário |
# MAGIC | `previsao_horaria` / `previsao_diaria` | `api.open-meteo.com/v1/forecast` | últimos 7 dias + 16 dias de previsão; cobre o atraso de ~5 dias do arquivo |
# MAGIC | `atual` | idem (`current=`) | condições atuais (atualizadas a cada 15 min pela Open-Meteo) |
# MAGIC | `locais` | IBGE malhas (centroide) | coordenadas de cada município |
# MAGIC | `unidades` | idem | unidade de cada variável |
# MAGIC
# MAGIC **Locais:** por defeito as 27 capitais. Pode acrescentar códigos IBGE no widget `municipios`
# MAGIC (ex.: `capitais,3509502,3170206` para juntar Campinas e Uberlândia — útil para as cidades do Olist).
# MAGIC
# MAGIC **Limites da API gratuita** (uso não comercial): ~600 pedidos/min, 5.000/hora, 10.000/dia, e pedidos com
# MAGIC muitas variáveis ou muitos dias contam como vários. O backfill completo pode precisar de mais de um dia:
# MAGIC quando o limite é atingido o notebook para sem erro e a execução seguinte continua do watermark.
# MAGIC Para uso comercial é preciso uma chave (secret `open_meteo/apikey`), que passa a usar os endpoints `customer-`.

# COMMAND ----------

# MAGIC %run ./_comum

# COMMAND ----------

dbutils.widgets.text("catalog", "dev_contexto_br", "Catálogo")
dbutils.widgets.text("municipios", "capitais", "Municípios (capitais e/ou códigos IBGE)")
dbutils.widgets.text("data_inicio_diario", "2016-01-01", "Início do histórico diário")
dbutils.widgets.text("data_inicio_horario", "2024-01-01", "Início do histórico horário")
dbutils.widgets.text("horas_entre_previsoes", "3", "Horas entre pedidos de previsão")
dbutils.widgets.text("secret_scope_apikey", "", "Secret scope com 'apikey' (opcional)")
dbutils.widgets.dropdown("forcar_recarga", "nao", ["nao", "sim"], "Ignorar watermarks")

configurar(dbutils.widgets.get("catalog"))
INICIO_DIARIO = para_data(dbutils.widgets.get("data_inicio_diario"))
INICIO_HORARIO = para_data(dbutils.widgets.get("data_inicio_horario"))
HORAS_PREVISAO = float(dbutils.widgets.get("horas_entre_previsoes"))
FORCAR = dbutils.widgets.get("forcar_recarga") == "sim"
HOJE = dt.date.today()
FIM_ARQUIVO = HOJE - dt.timedelta(days=6)  # o arquivo tem ~5 dias de atraso

APIKEY = None
scope = dbutils.widgets.get("secret_scope_apikey").strip()
if scope:
    APIKEY = dbutils.secrets.get(scope=scope, key="apikey")

URL_ARQUIVO = "https://customer-archive-api.open-meteo.com/v1/archive" if APIKEY else "https://archive-api.open-meteo.com/v1/archive"
URL_PREVISAO = "https://customer-api.open-meteo.com/v1/forecast" if APIKEY else "https://api.open-meteo.com/v1/forecast"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Variáveis pedidas
# MAGIC
# MAGIC Arquivo e previsão não têm exatamente as mesmas variáveis (ex.: solo e vento em altura).
# MAGIC Se a API recusar alguma, o notebook retira-a e repete o pedido. Se mudar estas listas,
# MAGIC atualize também `VARIAVEIS_*` em `src/pipeline/silver_meteo.py` para as ver como colunas tipadas
# MAGIC (as restantes ficam sempre disponíveis na coluna `payload` da silver).

# COMMAND ----------

ARQUIVO_DIARIO = [
    "weather_code", "temperature_2m_max", "temperature_2m_min", "temperature_2m_mean",
    "apparent_temperature_max", "apparent_temperature_min", "apparent_temperature_mean",
    "sunrise", "sunset", "daylight_duration", "sunshine_duration",
    "precipitation_sum", "rain_sum", "snowfall_sum", "precipitation_hours",
    "wind_speed_10m_max", "wind_gusts_10m_max", "wind_direction_10m_dominant",
    "shortwave_radiation_sum", "et0_fao_evapotranspiration",
]

ARQUIVO_HORARIO = [
    "temperature_2m", "relative_humidity_2m", "dew_point_2m", "apparent_temperature",
    "precipitation", "rain", "snowfall", "snow_depth", "weather_code",
    "pressure_msl", "surface_pressure", "cloud_cover", "cloud_cover_low", "cloud_cover_mid", "cloud_cover_high",
    "et0_fao_evapotranspiration", "vapour_pressure_deficit",
    "wind_speed_10m", "wind_speed_100m", "wind_direction_10m", "wind_direction_100m", "wind_gusts_10m",
    "shortwave_radiation", "direct_radiation", "diffuse_radiation", "direct_normal_irradiance",
    "sunshine_duration", "is_day",
    "soil_temperature_0_to_7cm", "soil_moisture_0_to_7cm",
]

PREVISAO_DIARIA = [
    "weather_code", "temperature_2m_max", "temperature_2m_min", "temperature_2m_mean",
    "apparent_temperature_max", "apparent_temperature_min",
    "sunrise", "sunset", "daylight_duration", "sunshine_duration", "uv_index_max",
    "precipitation_sum", "rain_sum", "showers_sum", "snowfall_sum", "precipitation_hours",
    "precipitation_probability_max", "wind_speed_10m_max", "wind_gusts_10m_max",
    "wind_direction_10m_dominant", "shortwave_radiation_sum", "et0_fao_evapotranspiration",
]

PREVISAO_HORARIA = [
    "temperature_2m", "relative_humidity_2m", "dew_point_2m", "apparent_temperature",
    "precipitation_probability", "precipitation", "rain", "showers", "snowfall", "weather_code",
    "pressure_msl", "surface_pressure", "cloud_cover", "cloud_cover_low", "cloud_cover_mid", "cloud_cover_high",
    "visibility", "evapotranspiration", "et0_fao_evapotranspiration", "vapour_pressure_deficit",
    "wind_speed_10m", "wind_direction_10m", "wind_gusts_10m", "uv_index", "is_day", "sunshine_duration",
    "shortwave_radiation", "direct_radiation", "diffuse_radiation",
]

ATUAL = [
    "temperature_2m", "relative_humidity_2m", "apparent_temperature", "is_day", "precipitation",
    "rain", "showers", "snowfall", "weather_code", "cloud_cover", "pressure_msl", "surface_pressure",
    "wind_speed_10m", "wind_direction_10m", "wind_gusts_10m",
]

# COMMAND ----------

# MAGIC %md ## Locais (capitais + códigos extra) e coordenadas

# COMMAND ----------

CAPITAIS = {
    "1100205": "Porto Velho", "1200401": "Rio Branco", "1302603": "Manaus", "1400100": "Boa Vista",
    "1501402": "Belém", "1600303": "Macapá", "1721000": "Palmas", "2111300": "São Luís",
    "2211001": "Teresina", "2304400": "Fortaleza", "2408102": "Natal", "2507507": "João Pessoa",
    "2611606": "Recife", "2704302": "Maceió", "2800308": "Aracaju", "2927408": "Salvador",
    "3106200": "Belo Horizonte", "3205309": "Vitória", "3304557": "Rio de Janeiro", "3550308": "São Paulo",
    "4106902": "Curitiba", "4205407": "Florianópolis", "4314902": "Porto Alegre", "5002704": "Campo Grande",
    "5103403": "Cuiabá", "5208707": "Goiânia", "5300108": "Brasília",
}

codigos = []
for item in dbutils.widgets.get("municipios").split(","):
    item = item.strip()
    if not item:
        continue
    if item.lower() == "capitais":
        codigos.extend(CAPITAIS.keys())
    elif item.isdigit() and len(item) == 7:
        codigos.append(item)
    else:
        print(f"  ! ignorado (não é um código IBGE de 7 dígitos): {item}")
codigos = list(dict.fromkeys(codigos))
print(f"{len(codigos)} municípios configurados.")

# COMMAND ----------

def coordenadas_ibge(cod):
    """Nome/UF (localidades) + centroide e área (malhas). Devolve dict ou None."""
    info = http_get(f"https://servicodados.ibge.gov.br/api/v1/localidades/municipios/{cod}").json()
    if isinstance(info, list):
        info = info[0] if info else {}
    nome = info.get("nome")
    uf = (((info.get("microrregiao") or {}).get("mesorregiao") or {}).get("UF") or {}).get("sigla") \
        or (((info.get("regiao-imediata") or {}).get("regiao-intermediaria") or {}).get("UF") or {}).get("sigla")

    lat = lon = area = None
    fonte = None
    try:
        meta = http_get(f"https://servicodados.ibge.gov.br/api/v3/malhas/municipios/{cod}/metadados").json()
        meta = meta[0] if isinstance(meta, list) and meta else meta
        centro = (meta or {}).get("centroide") or {}
        lat, lon = centro.get("latitude"), centro.get("longitude")
        dim = ((meta or {}).get("area") or {}).get("dimensao")
        area = float(str(dim).replace(",", ".")) if dim not in (None, "") else None
        fonte = "ibge_malhas" if lat is not None else None
    except Exception as e:
        print(f"  ! malhas IBGE falhou para {cod}: {e}")

    if lat is None and nome:
        # Alternativa: geocoding da Open-Meteo, filtrado pelo Brasil e pela UF
        geo = http_get("https://geocoding-api.open-meteo.com/v1/search",
                       {"name": nome, "count": 10, "language": "pt", "countryCode": "BR"}).json()
        for r in geo.get("results") or []:
            lat, lon, fonte = r.get("latitude"), r.get("longitude"), "open_meteo_geocoding"
            break

    if lat is None:
        return None
    return {"cod_municipio": cod, "municipio": nome, "sigla_uf": uf, "latitude": float(lat),
            "longitude": float(lon), "area_km2": area, "fonte_coordenadas": fonte}


cache = {r["cod_municipio"]: r.asDict() for r in spark.table(f"{CATALOGO}.ops.meteo_locais").collect()}
novos = []
for cod in codigos:
    if cod in cache and not FORCAR:
        continue
    try:
        loc = coordenadas_ibge(cod)
        if loc:
            novos.append(loc)
            cache[cod] = loc
            print(f"  ✓ {cod} {loc['municipio']}/{loc['sigla_uf']}: {loc['latitude']:.4f}, {loc['longitude']:.4f}")
        else:
            print(f"  ✗ sem coordenadas para {cod}")
    except Exception as e:
        print(f"  ✗ {cod}: {e}")
    time.sleep(0.3)

if novos:
    from pyspark.sql import functions as F
    (spark.createDataFrame(novos, "cod_municipio string, municipio string, sigla_uf string, latitude double, "
                                  "longitude double, area_km2 double, fonte_coordenadas string")
          .withColumn("atualizado_em", F.current_timestamp())
          .createOrReplaceTempView("novos_locais"))
    spark.sql(f"""
        MERGE INTO {CATALOGO}.ops.meteo_locais t USING novos_locais s ON t.cod_municipio = s.cod_municipio
        WHEN MATCHED THEN UPDATE SET * WHEN NOT MATCHED THEN INSERT *
    """)

locais = [cache[c] for c in codigos if c in cache]
if novos or precisa_refrescar(spark, "meteo", "locais", 24, FORCAR):
    gravar_landing("meteo", "locais", locais, "ops.meteo_locais")
    gravar_controlo(spark, "meteo", "locais", str(len(locais)))

# COMMAND ----------

# MAGIC %md ## Pedidos à Open-Meteo

# COMMAND ----------

def pedir_open_meteo(url, params, variaveis_por_bloco):
    """Faz o pedido; se a API recusar uma variável (HTTP 400), retira-a e tenta de novo."""
    for _ in range(6):
        p = dict(params)
        for bloco, lista in variaveis_por_bloco.items():
            p[bloco] = ",".join(lista)
        if APIKEY:
            p["apikey"] = APIKEY
        try:
            return open_meteo_como_lista(http_get(url, p, timeout=180).json())
        except requests.HTTPError as e:
            if e.response is None or e.response.status_code != 400:
                raise
            texto = e.response.text
            todas = [v for lista in variaveis_por_bloco.values() for v in lista]
            invalida = variavel_invalida_open_meteo(texto, todas)
            if not invalida:
                raise
            print(f"  ! variável recusada pela API, retirada: {invalida}")
            for lista in variaveis_por_bloco.values():
                if invalida in lista:
                    lista.remove(invalida)
    raise RuntimeError("Demasiadas variáveis recusadas pela Open-Meteo.")


def url_sem_chave(url, params):
    return url_final(url, {k: v for k, v in params.items() if k != "apikey"})


def em_lotes(lista, tamanho):
    for i in range(0, len(lista), tamanho):
        yield lista[i:i + tamanho]


def coords(lote):
    return {"latitude": ",".join(str(l["latitude"]) for l in lote),
            "longitude": ",".join(str(l["longitude"]) for l in lote)}

# COMMAND ----------

# MAGIC %md ## Histórico (arquivo) — diário e horário, incremental por município

# COMMAND ----------

def carregar_arquivo(dataset, bloco, variaveis, inicio_defeito, dias_por_pedido):
    chave_ctl = f"arquivo_{bloco}"
    # Agrupar municípios pela data a partir da qual faltam dados (normalmente todos iguais)
    por_inicio = {}
    for loc in locais:
        marca = None if FORCAR else ler_controlo(spark, f"meteo_{chave_ctl}", loc["cod_municipio"])
        if marca is not None and para_data(marca) >= FIM_ARQUIVO:
            continue  # já atualizado; só volta a pedir quando houver um dia novo no arquivo
        # volta 6 dias atrás: a reanálise preliminar (ERA5T) ainda pode ser revista
        inicio = inicio_defeito if marca is None else para_data(marca) - dt.timedelta(days=6)
        inicio = max(inicio, inicio_defeito)
        if inicio <= FIM_ARQUIVO:
            por_inicio.setdefault(inicio, []).append(loc)

    for inicio, grupo in sorted(por_inicio.items()):
        for lote in em_lotes(grupo, 10):
            for de, ate in blocos_de_datas(inicio, FIM_ARQUIVO, dias_por_pedido):
                params = {**coords(lote), "start_date": de.isoformat(), "end_date": ate.isoformat(),
                          "timezone": "auto"}
                vpb = {bloco: variaveis}
                respostas = pedir_open_meteo(URL_ARQUIVO, params, vpb)
                url = url_sem_chave(URL_ARQUIVO, {**params, bloco: ",".join(variaveis)})
                for loc, resp in zip(lote, respostas):
                    linhas = open_meteo_bloco_para_linhas(resp, bloco)
                    gravar_landing("meteo", dataset, linhas, url, contexto={
                        "cod_municipio": loc["cod_municipio"], "municipio": loc["municipio"],
                        "sigla_uf": loc["sigla_uf"], "latitude_pedida": loc["latitude"],
                        "longitude_pedida": loc["longitude"], "modelo": "era5_reanalise",
                    })
                    gravar_controlo(spark, f"meteo_{chave_ctl}", loc["cod_municipio"], ate.isoformat())
                time.sleep(1)


if not locais:
    dbutils.notebook.exit("Sem municípios com coordenadas; nada a carregar.")

limite_atingido = False
try:
    carregar_arquivo("arquivo_diario", "daily", ARQUIVO_DIARIO, INICIO_DIARIO, dias_por_pedido=366)
    carregar_arquivo("arquivo_horario", "hourly", ARQUIVO_HORARIO, INICIO_HORARIO, dias_por_pedido=92)
except LimiteDiarioExcedido as e:
    limite_atingido = True
    print(f"Limite da Open-Meteo atingido; o backfill continua na próxima execução. ({e})")

# COMMAND ----------

# MAGIC %md ## Previsão + últimos 7 dias + condições atuais

# COMMAND ----------

if not limite_atingido and precisa_refrescar(spark, "meteo", "previsao", HORAS_PREVISAO, FORCAR):
    try:
        for lote in em_lotes(locais, 10):
            params = {**coords(lote), "past_days": 7, "forecast_days": 16, "timezone": "auto"}
            vpb = {"hourly": PREVISAO_HORARIA, "daily": PREVISAO_DIARIA, "current": ATUAL}
            respostas = pedir_open_meteo(URL_PREVISAO, params, vpb)
            url = url_sem_chave(URL_PREVISAO, {**params, **{b: ",".join(v) for b, v in vpb.items()}})
            for loc, resp in zip(lote, respostas):
                ctx = {"cod_municipio": loc["cod_municipio"], "municipio": loc["municipio"],
                       "sigla_uf": loc["sigla_uf"], "latitude_pedida": loc["latitude"],
                       "longitude_pedida": loc["longitude"], "modelo": "best_match"}
                gravar_landing("meteo", "previsao_horaria", open_meteo_bloco_para_linhas(resp, "hourly"), url, ctx)
                gravar_landing("meteo", "previsao_diaria", open_meteo_bloco_para_linhas(resp, "daily"), url, ctx)
                atual = open_meteo_atual_para_linha(resp)
                gravar_landing("meteo", "atual", [atual] if atual else [], url, ctx)
            time.sleep(1)

        if precisa_refrescar(spark, "meteo", "unidades", 24, FORCAR) and respostas:
            unidades = open_meteo_unidades(respostas[0], "forecast")
            # unidades do arquivo: um pedido mínimo de um dia
            amostra = pedir_open_meteo(URL_ARQUIVO, {**coords(locais[:1]), "start_date": FIM_ARQUIVO.isoformat(),
                                                     "end_date": FIM_ARQUIVO.isoformat(), "timezone": "auto"},
                                       {"daily": ARQUIVO_DIARIO, "hourly": ARQUIVO_HORARIO})
            unidades += open_meteo_unidades(amostra[0], "archive")
            gravar_landing("meteo", "unidades", unidades, "open-meteo *_units")
            gravar_controlo(spark, "meteo", "unidades", str(len(unidades)))

        gravar_controlo(spark, "meteo", "previsao", dt.datetime.now(dt.timezone.utc).isoformat())
    except LimiteDiarioExcedido as e:
        print(f"Limite da Open-Meteo atingido na previsão; tenta de novo na próxima execução. ({e})")
else:
    print("Previsão recente já carregada; ignorada nesta execução.")

print("Meteorologia concluída.")
