# Databricks notebook source
# MAGIC %md
# MAGIC # 00 · Setup (idempotente)
# MAGIC
# MAGIC Cria os schemas da arquitetura medalhão, o volume da landing zone e as tabelas de controlo.
# MAGIC Corre no início de cada execução do job; se já existir tudo, não faz nada.
# MAGIC
# MAGIC O **catálogo** tem de existir (criá-lo exige permissões de metastore admin).
# MAGIC Por defeito: `dev_contexto_br` / `prod_contexto_br` (isolamento por ambiente).

# COMMAND ----------

dbutils.widgets.text("catalog", "dev_contexto_br", "Catálogo")
CATALOGO = dbutils.widgets.get("catalog").strip()

# COMMAND ----------

existe = spark.sql("SHOW CATALOGS").filter(f"catalog = '{CATALOGO}'").count() > 0
if not existe:
    try:
        spark.sql(f"CREATE CATALOG IF NOT EXISTS {CATALOGO} COMMENT 'Dados de contexto do Brasil (câmbio, inflação, feriados, IBGE, meteorologia)'")
        print(f"Catálogo {CATALOGO} criado.")
    except Exception as e:
        raise RuntimeError(
            f"O catálogo '{CATALOGO}' não existe e não foi possível criá-lo ({e}). "
            "Peça a um metastore admin para o criar, ou altere a variável 'catalog' do bundle."
        )

esquemas = {
    "bronze": "Camada bronze: registos brutos das APIs, tal como chegaram (Auto Loader).",
    "silver": "Camada silver: dados tipados, validados e deduplicados (AUTO CDC).",
    "gold": "Camada gold: dimensões e factos prontos para consumo (materialized views).",
    "ops": "Operação: landing zone, watermarks e cache de coordenadas.",
}
for esquema, comentario in esquemas.items():
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOGO}.{esquema} COMMENT '{comentario}'")

spark.sql(f"CREATE VOLUME IF NOT EXISTS {CATALOGO}.ops.landing COMMENT 'Landing zone: JSON Lines escritos pelos notebooks de ingestão'")

# Pastas da landing zone: o Auto Loader do bronze precisa que existam, mesmo vazias
import os
PASTAS = [
    "bcb/sgs", "bcb/ptax_cotacoes", "bcb/ptax_moedas", "bce/exr",
    "feriados/brasilapi", "feriados/nager",
    "ibge/municipios", "ibge/estados", "ibge/populacao_estimada", "ibge/censo_2022",
    "meteo/locais", "meteo/unidades", "meteo/arquivo_diario", "meteo/arquivo_horario",
    "meteo/previsao_diaria", "meteo/previsao_horaria", "meteo/atual",
]
for p in PASTAS:
    os.makedirs(f"/Volumes/{CATALOGO}/ops/landing/{p}", exist_ok=True)

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {CATALOGO}.ops.controlo_ingestao (
  fonte STRING NOT NULL COMMENT 'Fonte/dataset (ex.: bcb_sgs)',
  chave STRING NOT NULL COMMENT 'Chave do watermark (ex.: código da série, município)',
  valor STRING COMMENT 'Último valor carregado (data ISO, etc.)',
  atualizado_em TIMESTAMP COMMENT 'Quando o watermark foi gravado (UTC)',
  lote_id STRING COMMENT 'Execução que gravou o watermark'
) COMMENT 'Watermarks das cargas incrementais'
""")

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {CATALOGO}.ops.meteo_locais (
  cod_municipio STRING NOT NULL,
  municipio STRING,
  sigla_uf STRING,
  latitude DOUBLE,
  longitude DOUBLE,
  area_km2 DOUBLE,
  fonte_coordenadas STRING COMMENT 'ibge_malhas (centroide) ou open_meteo_geocoding',
  atualizado_em TIMESTAMP
) COMMENT 'Cache das coordenadas usadas nos pedidos de meteorologia'
""")

print("Setup concluído.")
display(spark.sql(f"SHOW SCHEMAS IN {CATALOGO}"))
