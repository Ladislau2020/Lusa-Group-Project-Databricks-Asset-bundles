# Databricks notebook source
# MAGIC %md
# MAGIC # 03 · Feriados do Brasil
# MAGIC
# MAGIC Duas fontes gratuitas e sem autenticação, que se complementam:
# MAGIC
# MAGIC | Fonte | Endpoint | O que acrescenta |
# MAGIC |---|---|---|
# MAGIC | **BrasilAPI** | `brasilapi.com.br/api/feriados/v1/{ano}` | nome oficial em PT, tipo (`national` / pontos facultativos), inclui feriados móveis |
# MAGIC | **Nager.Date** | `date.nager.at/api/v3/PublicHolidays/{ano}/BR` | nome em inglês, feriado fixo vs móvel, nacional vs regional (`global`), UFs abrangidas (`counties`), ano de criação, tipos |
# MAGIC
# MAGIC Os feriados mudam pouco: o histórico carrega uma vez e depois só se refrescam o ano atual
# MAGIC e o seguinte, no máximo uma vez a cada 20 horas.

# COMMAND ----------

# MAGIC %run ./_comum

# COMMAND ----------

dbutils.widgets.text("catalog", "dev_contexto_br", "Catálogo")
dbutils.widgets.text("ano_inicio", "2010", "Primeiro ano")
dbutils.widgets.text("anos_a_frente", "2", "Anos futuros a carregar")
dbutils.widgets.dropdown("forcar_recarga", "nao", ["nao", "sim"], "Recarregar tudo")

configurar(dbutils.widgets.get("catalog"))
ANO_INICIO = int(dbutils.widgets.get("ano_inicio"))
ANOS_FRENTE = int(dbutils.widgets.get("anos_a_frente"))
FORCAR = dbutils.widgets.get("forcar_recarga") == "sim"
ANO_ATUAL = dt.date.today().year

FONTES = {
    "brasilapi": "https://brasilapi.com.br/api/feriados/v1/{ano}",
    "nager": "https://date.nager.at/api/v3/PublicHolidays/{ano}/BR",
}

# COMMAND ----------

falhas = []
for fonte, modelo_url in FONTES.items():
    for ano in range(ANO_INICIO, ANO_ATUAL + ANOS_FRENTE + 1):
        ja_carregado = ler_controlo(spark, f"feriados_{fonte}", str(ano)) is not None
        ano_recente = ano >= ANO_ATUAL  # ano atual e futuros podem ser revistos
        if ja_carregado and not FORCAR:
            if not ano_recente or not precisa_refrescar(spark, f"feriados_{fonte}", str(ano), horas=20):
                continue
        url = modelo_url.format(ano=ano)
        try:
            r = http_get(url, aceitar_404=True)
            registos = [] if r is None else r.json()
            gravar_landing("feriados", fonte, registos, url, contexto={"ano": ano})
            gravar_controlo(spark, f"feriados_{fonte}", str(ano), str(len(registos)))
        except Exception as e:
            print(f"  ✗ {fonte} {ano}: {e}")
            falhas.append(f"{fonte}:{ano}")
        time.sleep(0.3)

if falhas:
    raise RuntimeError(f"Feriados com falha: {falhas}")
print("Feriados concluídos.")
