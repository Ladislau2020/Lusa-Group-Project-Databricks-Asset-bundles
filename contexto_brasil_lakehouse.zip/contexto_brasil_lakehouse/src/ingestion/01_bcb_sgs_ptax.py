# Databricks notebook source
# MAGIC %md
# MAGIC # 01 · Banco Central do Brasil — câmbio, inflação e juros
# MAGIC
# MAGIC Duas APIs do BCB, ambas sem autenticação:
# MAGIC
# MAGIC 1. **SGS** (`api.bcb.gov.br/dados/serie/bcdata.sgs.{codigo}/dados`) — séries temporais de câmbio,
# MAGIC    inflação e juros. Limite: pedidos de no máximo **10 anos**, por isso a carga é feita em blocos.
# MAGIC 2. **PTAX** (`olinda.bcb.gov.br/.../PTAX`) — cotações oficiais de 10 moedas, com **todos os boletins**
# MAGIC    do dia (abertura, intermédios, fecho), compra/venda e paridade face ao USD.
# MAGIC
# MAGIC Carga incremental: cada série/moeda guarda um watermark em `ops.controlo_ingestao`.
# MAGIC Em cada execução volta a pedir uma pequena janela para trás (`sobreposicao`), para apanhar
# MAGIC revisões — a deduplicação é feita na silver.

# COMMAND ----------

# MAGIC %run ./_comum

# COMMAND ----------

dbutils.widgets.text("catalog", "dev_contexto_br", "Catálogo")
dbutils.widgets.text("data_inicio", "2016-01-01", "Data inicial do histórico")
dbutils.widgets.dropdown("forcar_recarga", "nao", ["nao", "sim"], "Ignorar watermarks")

configurar(dbutils.widgets.get("catalog"))
DATA_INICIO = para_data(dbutils.widgets.get("data_inicio"))
FORCAR = dbutils.widgets.get("forcar_recarga") == "sim"
HOJE = dt.date.today()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Catálogo de séries SGS
# MAGIC
# MAGIC Os metadados (nome, categoria, unidade, periodicidade) viajam no `contexto` do envelope e chegam
# MAGIC à silver como colunas. Para acrescentar uma série basta acrescentar uma linha — pesquise códigos em
# MAGIC https://www3.bcb.gov.br/sgspub

# COMMAND ----------

SERIES_SGS = [
    # Câmbio
    {"codigo": 1,     "nome": "Dólar americano (venda) - livre",           "categoria": "cambio",   "unidade": "BRL/USD",  "periodicidade": "diaria"},
    {"codigo": 10813, "nome": "Dólar americano (compra) - livre",          "categoria": "cambio",   "unidade": "BRL/USD",  "periodicidade": "diaria"},
    {"codigo": 21619, "nome": "Euro (venda)",                              "categoria": "cambio",   "unidade": "BRL/EUR",  "periodicidade": "diaria"},
    {"codigo": 21620, "nome": "Euro (compra)",                             "categoria": "cambio",   "unidade": "BRL/EUR",  "periodicidade": "diaria"},
    # Inflação
    {"codigo": 433,   "nome": "IPCA - variação mensal",                    "categoria": "inflacao", "unidade": "% a.m.",   "periodicidade": "mensal"},
    {"codigo": 13522, "nome": "IPCA - acumulado 12 meses",                 "categoria": "inflacao", "unidade": "% 12m",    "periodicidade": "mensal"},
    {"codigo": 188,   "nome": "INPC - variação mensal",                    "categoria": "inflacao", "unidade": "% a.m.",   "periodicidade": "mensal"},
    {"codigo": 189,   "nome": "IGP-M - variação mensal",                   "categoria": "inflacao", "unidade": "% a.m.",   "periodicidade": "mensal"},
    {"codigo": 190,   "nome": "IGP-DI - variação mensal",                  "categoria": "inflacao", "unidade": "% a.m.",   "periodicidade": "mensal"},
    # Juros
    {"codigo": 11,    "nome": "Taxa Selic diária",                         "categoria": "juros",    "unidade": "% a.d.",   "periodicidade": "diaria"},
    {"codigo": 432,   "nome": "Meta da taxa Selic (Copom)",                "categoria": "juros",    "unidade": "% a.a.",   "periodicidade": "diaria"},
    {"codigo": 12,    "nome": "CDI diário",                                "categoria": "juros",    "unidade": "% a.d.",   "periodicidade": "diaria"},
]

# Janela que se volta a pedir em cada execução, para apanhar revisões
SOBREPOSICAO = {"diaria": dt.timedelta(days=10), "mensal": dt.timedelta(days=100)}
BLOCO_DIAS = 3650  # < 10 anos, limite da API

# COMMAND ----------

# MAGIC %md ## SGS

# COMMAND ----------

def carregar_serie_sgs(serie):
    codigo = serie["codigo"]
    chave = str(codigo)
    marca = None if FORCAR else ler_controlo(spark, "bcb_sgs", chave)
    inicio = DATA_INICIO if marca is None else max(DATA_INICIO, para_data(marca) - SOBREPOSICAO[serie["periodicidade"]])
    print(f"SGS {codigo} · {serie['nome']} · de {inicio} a {HOJE}")

    url_base = f"https://api.bcb.gov.br/dados/serie/bcdata.sgs.{codigo}/dados"
    maior_data = marca
    for de, ate in blocos_de_datas(inicio, HOJE, BLOCO_DIAS):
        params = {"formato": "json", "dataInicial": f"{de:%d/%m/%Y}", "dataFinal": f"{ate:%d/%m/%Y}"}
        r = http_get(url_base, params, aceitar_404=True)
        dados = [] if r is None else r.json()
        if isinstance(dados, dict):  # mensagem de erro em JSON
            print(f"  ! resposta inesperada: {dados}")
            continue
        gravar_landing("bcb", "sgs", dados, url_final(url_base, params), contexto={
            "serie_codigo": codigo, "serie_nome": serie["nome"], "categoria": serie["categoria"],
            "unidade": serie["unidade"], "periodicidade": serie["periodicidade"],
        })
        if dados:
            ultima = max(bcb_data_para_iso(d["data"]) for d in dados)
            maior_data = ultima if maior_data is None else max(maior_data, ultima)
        time.sleep(0.5)

    if maior_data:
        gravar_controlo(spark, "bcb_sgs", chave, maior_data)


falhas = []
for s in SERIES_SGS:
    try:
        carregar_serie_sgs(s)
    except Exception as e:
        print(f"  ✗ série {s['codigo']} falhou: {e}")
        falhas.append(f"sgs:{s['codigo']}")

# COMMAND ----------

# MAGIC %md ## PTAX — moedas e cotações (todos os boletins)

# COMMAND ----------

URL_MOEDAS = "https://olinda.bcb.gov.br/olinda/servico/PTAX/versao/v1/odata/Moedas?$top=1000&$format=json"
moedas = []
try:
    moedas = http_get(URL_MOEDAS).json().get("value", [])
    if precisa_refrescar(spark, "bcb_ptax_moedas", "lista", horas=24, forcar=FORCAR):
        gravar_landing("bcb", "ptax_moedas", moedas, URL_MOEDAS)
        gravar_controlo(spark, "bcb_ptax_moedas", "lista", HOJE.isoformat())
except Exception as e:
    print(f"  ✗ lista de moedas PTAX falhou: {e}")
    falhas.append("ptax:moedas")

# A lista de moedas da PTAX não inclui o USD (é a moeda de referência das paridades)
simbolos = sorted({m["simbolo"] for m in moedas} | {"USD"})
print("Moedas PTAX:", simbolos)

# COMMAND ----------

def carregar_ptax(moeda):
    marca = None if FORCAR else ler_controlo(spark, "bcb_ptax", moeda)
    inicio = DATA_INICIO if marca is None else max(DATA_INICIO, para_data(marca) - dt.timedelta(days=10))
    print(f"PTAX {moeda} · de {inicio} a {HOJE}")
    maior_data = marca
    for de, ate in blocos_de_datas(inicio, HOJE, 366):
        url = ptax_url_cotacoes(moeda, de, ate)
        valores = http_get(url).json().get("value", [])
        gravar_landing("bcb", "ptax_cotacoes", valores, url, contexto={"moeda": moeda})
        if valores:
            ultima = max(v["dataHoraCotacao"][:10] for v in valores)
            maior_data = ultima if maior_data is None else max(maior_data, ultima)
        time.sleep(0.5)
    if maior_data:
        gravar_controlo(spark, "bcb_ptax", moeda, maior_data)


for m in simbolos:
    try:
        carregar_ptax(m)
    except Exception as e:
        print(f"  ✗ PTAX {m} falhou: {e}")
        falhas.append(f"ptax:{m}")

# COMMAND ----------

if falhas:
    # Falha a tarefa para ficar visível no job; os dados que chegaram ficam na landing
    # e o pipeline corre na mesma (run_if = AT_LEAST_ONE_SUCCESS / ALL_DONE).
    raise RuntimeError(f"Fontes BCB com falha: {falhas}")
print("BCB concluído.")
