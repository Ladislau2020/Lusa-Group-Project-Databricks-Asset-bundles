"""
SILVER — feriados (BrasilAPI + Nager.Date) e IBGE (municípios, estados, população).

Os municípios ficam em SCD tipo 2: se o IBGE mudar o nome de um município ou a sua região,
a versão anterior fica guardada com __START_AT / __END_AT.
"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F

CAT = spark.conf.get("contexto.catalog")
LINHAGEM = ["ingestao_ts", "_lote_id", "_linha", "ficheiro", "_url"]
SEQ = F.struct("ingestao_ts", "_linha")


def bronze(tabela):
    return spark.readStream.table(f"{CAT}.bronze.{tabela}").withColumn("pv", F.expr("parse_json(payload)"))


def pj(campo, tipo="string"):
    return F.expr(f"try_variant_get(pv, '$.{campo}', '{tipo}')")


def ctx(chave):
    return F.col("contexto").getItem(chave)


def upsert(tabela, view, chaves, comentario, scd=1, cluster_by=None):
    dp.create_streaming_table(
        name=f"{CAT}.silver.{tabela}",
        comment=comentario,
        table_properties={"quality": "silver", "delta.enableChangeDataFeed": "true"},
        cluster_by=cluster_by,
    )
    extra = {}
    if scd == 2:
        # Só abre nova versão quando um atributo de negócio muda (não quando muda a linhagem)
        extra["track_history_except_column_list"] = LINHAGEM
    dp.create_auto_cdc_flow(
        target=f"{CAT}.silver.{tabela}",
        source=view,
        keys=chaves,
        sequence_by=SEQ,
        stored_as_scd_type=scd,
        name=f"cdc_{tabela}",
        **extra,
    )


# ---------------------------------------------------------------- Feriados
@dp.temporary_view(name="v_feriados_brasilapi")
@dp.expect_or_drop("data_e_nome", "data IS NOT NULL AND nome IS NOT NULL")
def v_feriados_brasilapi():
    return bronze("feriados_brasilapi").select(
        F.to_date(F.try_to_timestamp(pj("date"), F.lit("yyyy-MM-dd"))).alias("data"),
        ctx("ano").cast("int").alias("ano"),
        pj("name").alias("nome"),
        F.coalesce(pj("full_name"), pj("fullName")).alias("nome_completo"),
        pj("type").alias("tipo"),
        F.when(pj("type") == "national", "Feriado nacional")
         .when(pj("type") == "optional", "Ponto facultativo")
         .otherwise(pj("type")).alias("tipo_descricao"),
        F.col("payload").alias("registo_original"),
        *LINHAGEM,
    )


upsert("feriados_brasilapi", "v_feriados_brasilapi", ["data", "nome"],
       "Feriados nacionais e pontos facultativos do Brasil (BrasilAPI).")


@dp.temporary_view(name="v_feriados_nager")
@dp.expect_or_drop("data_e_nome", "data IS NOT NULL AND nome_en IS NOT NULL")
def v_feriados_nager():
    return bronze("feriados_nager").select(
        F.to_date(F.try_to_timestamp(pj("date"), F.lit("yyyy-MM-dd"))).alias("data"),
        ctx("ano").cast("int").alias("ano"),
        pj("localName").alias("nome_local"),
        pj("name").alias("nome_en"),
        pj("countryCode").alias("pais"),
        pj("fixed", "boolean").alias("data_fixa"),
        pj("global", "boolean").alias("nacional"),
        pj("counties", "array<string>").alias("subdivisoes"),
        F.expr("transform(try_variant_get(pv, '$.counties', 'array<string>'), c -> replace(c, 'BR-', ''))")
         .alias("ufs"),
        pj("launchYear", "int").alias("ano_criacao"),
        pj("types", "array<string>").alias("tipos"),
        F.col("payload").alias("registo_original"),
        *LINHAGEM,
    )


upsert("feriados_nager", "v_feriados_nager", ["data", "nome_en"],
       "Feriados do Brasil (Nager.Date): data fixa vs móvel, nacional vs regional, UFs abrangidas, tipos.")


# ---------------------------------------------------------------- IBGE municípios
_REGIAO = "STRUCT<id: BIGINT, sigla: STRING, nome: STRING>"
_UF = f"STRUCT<id: BIGINT, sigla: STRING, nome: STRING, regiao: {_REGIAO}>"
SCHEMA_MUNICIPIO = (
    "id BIGINT, nome STRING, "
    f"microrregiao STRUCT<id: BIGINT, nome: STRING, mesorregiao: STRUCT<id: BIGINT, nome: STRING, UF: {_UF}>>, "
    f"`regiao-imediata` STRUCT<id: BIGINT, nome: STRING, "
    f"`regiao-intermediaria`: STRUCT<id: BIGINT, nome: STRING, UF: {_UF}>>"
)


@dp.temporary_view(name="v_ibge_municipios")
@dp.expect_or_drop("codigo_valido", "cod_municipio IS NOT NULL AND length(cast(cod_municipio AS STRING)) = 7")
@dp.expect("uf_identificada", "sigla_uf IS NOT NULL")
def v_ibge_municipios():
    m = F.from_json("payload", SCHEMA_MUNICIPIO)
    micro = m["microrregiao"]
    meso = micro["mesorregiao"]
    imed = m["regiao-imediata"]
    inter = imed["regiao-intermediaria"]
    uf = F.coalesce(meso["UF"], inter["UF"])
    return spark.readStream.table(f"{CAT}.bronze.ibge_municipios").select(
        m["id"].alias("cod_municipio"),
        m["nome"].alias("municipio"),
        micro["id"].alias("cod_microrregiao"),
        micro["nome"].alias("microrregiao"),
        meso["id"].alias("cod_mesorregiao"),
        meso["nome"].alias("mesorregiao"),
        imed["id"].alias("cod_regiao_imediata"),
        imed["nome"].alias("regiao_imediata"),
        inter["id"].alias("cod_regiao_intermediaria"),
        inter["nome"].alias("regiao_intermediaria"),
        uf["id"].alias("cod_uf"),
        uf["sigla"].alias("sigla_uf"),
        uf["nome"].alias("uf"),
        uf["regiao"]["id"].alias("cod_regiao"),
        uf["regiao"]["sigla"].alias("sigla_regiao"),
        uf["regiao"]["nome"].alias("regiao"),
        *LINHAGEM,
    )


upsert("ibge_municipios", "v_ibge_municipios", ["cod_municipio"],
       "Municípios do IBGE com toda a hierarquia territorial (SCD tipo 2).", scd=2)


@dp.temporary_view(name="v_ibge_estados")
@dp.expect_or_drop("codigo_valido", "cod_uf IS NOT NULL")
def v_ibge_estados():
    return bronze("ibge_estados").select(
        pj("id", "bigint").alias("cod_uf"),
        pj("sigla").alias("sigla_uf"),
        pj("nome").alias("uf"),
        pj("regiao.id", "bigint").alias("cod_regiao"),
        pj("regiao.sigla").alias("sigla_regiao"),
        pj("regiao.nome").alias("regiao"),
        *LINHAGEM,
    )


upsert("ibge_estados", "v_ibge_estados", ["cod_uf"], "Unidades da federação e grandes regiões (IBGE).")


# ---------------------------------------------------------------- IBGE população
def criar_populacao(tabela_bronze, tabela_silver, tipo, comentario):
    view = f"v_{tabela_silver}"

    @dp.temporary_view(name=view)
    @dp.expect_or_drop("chave_completa", "cod_municipio IS NOT NULL AND ano IS NOT NULL")
    @dp.expect("populacao_publicada", "populacao IS NOT NULL")  # o SIDRA usa '-' / '...' para ausentes
    def _v():
        return bronze(tabela_bronze).select(
            pj("localidade_id", "bigint").alias("cod_municipio"),
            pj("localidade_nome").alias("localidade_nome"),
            F.expr("try_cast(try_variant_get(pv, '$.periodo', 'string') AS INT)").alias("ano"),
            F.expr("try_cast(try_variant_get(pv, '$.valor', 'string') AS BIGINT)").alias("populacao"),
            pj("valor").alias("valor_original"),
            F.lit(tipo).alias("tipo_contagem"),
            pj("agregado").alias("tabela_sidra"),
            pj("variavel_id").alias("variavel_id"),
            pj("variavel").alias("variavel"),
            pj("unidade").alias("unidade"),
            *LINHAGEM,
        )

    upsert(tabela_silver, view, ["cod_municipio", "ano"], comentario)


criar_populacao("ibge_populacao_estimada", "ibge_populacao_estimada", "estimativa",
                "População residente estimada por município e ano (IBGE, SIDRA 6579).")
criar_populacao("ibge_censo_2022", "ibge_censo_2022", "censo",
                "População residente no Censo 2022 por município (IBGE, SIDRA 4709).")
