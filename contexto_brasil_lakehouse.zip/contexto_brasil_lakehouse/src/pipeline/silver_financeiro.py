"""
SILVER — câmbio, inflação e juros (BCB SGS, PTAX e BCE).

Padrão usado em todas as tabelas silver:
  1. uma *temporary view* em streaming lê o bronze, interpreta o `payload` (VARIANT), tipa as colunas
     e aplica expectations (qualidade de dados);
  2. um fluxo AUTO CDC faz o upsert na streaming table de destino (SCD tipo 1), deduplicando as
     sobreposições das cargas incrementais e ficando sempre com a versão mais recente de cada registo.
"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F

CAT = spark.conf.get("contexto.catalog")
LINHAGEM = ["ingestao_ts", "_lote_id", "_linha", "ficheiro", "_url"]
SEQ = F.struct("ingestao_ts", "_linha")


def bronze(tabela):
    return spark.readStream.table(f"{CAT}.bronze.{tabela}").withColumn("pv", F.expr("parse_json(payload)"))


def pj(campo, tipo="string"):
    """Campo do payload (VARIANT). Devolve NULL se não existir ou não converter."""
    return F.expr(f"try_variant_get(pv, '$.{campo}', '{tipo}')")


def data_de(col, formato):
    return F.to_date(F.try_to_timestamp(col, F.lit(formato)))


def ctx(chave):
    return F.col("contexto").getItem(chave)


def upsert(tabela, view, chaves, comentario, cluster_by=None):
    dp.create_streaming_table(
        name=f"{CAT}.silver.{tabela}",
        comment=comentario,
        table_properties={"quality": "silver", "delta.enableChangeDataFeed": "true"},
        cluster_by=cluster_by,
    )
    dp.create_auto_cdc_flow(
        target=f"{CAT}.silver.{tabela}",
        source=view,
        keys=chaves,
        sequence_by=SEQ,
        stored_as_scd_type=1,
        name=f"cdc_{tabela}",
    )


# ---------------------------------------------------------------- BCB SGS
@dp.temporary_view(name="v_bcb_sgs")
@dp.expect_or_drop("serie_identificada", "serie_codigo IS NOT NULL")
@dp.expect_or_drop("data_valida", "data IS NOT NULL")
@dp.expect("valor_numerico", "valor IS NOT NULL")
def v_bcb_sgs():
    return bronze("bcb_sgs").select(
        ctx("serie_codigo").cast("int").alias("serie_codigo"),
        ctx("serie_nome").alias("serie_nome"),
        ctx("categoria").alias("categoria"),
        ctx("unidade").alias("unidade"),
        ctx("periodicidade").alias("periodicidade"),
        data_de(pj("data"), "dd/MM/yyyy").alias("data"),
        data_de(pj("datafim"), "dd/MM/yyyy").alias("data_fim"),
        F.expr("try_cast(try_variant_get(pv, '$.valor', 'string') AS DOUBLE)").alias("valor"),
        F.col("payload").alias("registo_original"),
        *LINHAGEM,
    )


upsert("bcb_sgs", "v_bcb_sgs", ["serie_codigo", "data"],
       "Séries SGS do BCB (câmbio, inflação, juros), uma linha por série e data, com metadados da série.",
       cluster_by=["serie_codigo", "data"])


# ---------------------------------------------------------------- BCB PTAX
@dp.temporary_view(name="v_bcb_ptax_cotacoes")
@dp.expect_or_drop("moeda_e_hora", "moeda IS NOT NULL AND data_hora_cotacao IS NOT NULL")
@dp.expect("cotacoes_positivas", "cotacao_compra > 0 AND cotacao_venda > 0")
@dp.expect("venda_maior_ou_igual_compra", "cotacao_venda >= cotacao_compra")
def v_bcb_ptax_cotacoes():
    df = bronze("bcb_ptax_cotacoes").select(
        ctx("moeda").alias("moeda"),
        # hora de Brasília, guardada sem fuso (TIMESTAMP_NTZ)
        F.expr("try_cast(try_variant_get(pv, '$.dataHoraCotacao', 'string') AS TIMESTAMP_NTZ)")
         .alias("data_hora_cotacao"),
        pj("tipoBoletim").alias("tipo_boletim"),
        pj("cotacaoCompra", "double").alias("cotacao_compra"),
        pj("cotacaoVenda", "double").alias("cotacao_venda"),
        pj("paridadeCompra", "double").alias("paridade_compra"),
        pj("paridadeVenda", "double").alias("paridade_venda"),
        F.col("payload").alias("registo_original"),
        *LINHAGEM,
    )
    return (
        df.withColumn("data_cotacao", F.to_date("data_hora_cotacao"))
        .withColumn("cotacao_media", (F.col("cotacao_compra") + F.col("cotacao_venda")) / 2)
        .withColumn("spread", F.col("cotacao_venda") - F.col("cotacao_compra"))
        .withColumn("spread_pct", F.col("spread") / F.col("cotacao_media") * 100)
        .withColumn("e_fechamento", F.lower("tipo_boletim").startswith("fechamento"))
    )


upsert("bcb_ptax_cotacoes", "v_bcb_ptax_cotacoes", ["moeda", "data_hora_cotacao", "tipo_boletim"],
       "PTAX: todos os boletins (abertura, intermédios, fecho) por moeda; cotações em BRL por unidade "
       "e paridades face ao USD.",
       cluster_by=["moeda", "data_cotacao"])


@dp.temporary_view(name="v_bcb_ptax_moedas")
@dp.expect_or_drop("simbolo_presente", "simbolo IS NOT NULL")
def v_bcb_ptax_moedas():
    return bronze("bcb_ptax_moedas").select(
        pj("simbolo").alias("simbolo"),
        pj("nomeFormatado").alias("nome"),
        pj("tipoMoeda").alias("tipo_moeda"),
        F.when(pj("tipoMoeda") == "A", "paridade = unidades da moeda por 1 USD")
         .when(pj("tipoMoeda") == "B", "paridade = USD por 1 unidade da moeda")
         .alias("tipo_moeda_descricao"),
        *LINHAGEM,
    )


upsert("bcb_ptax_moedas", "v_bcb_ptax_moedas", ["simbolo"], "PTAX: moedas, nomes e tipo de paridade.")


# ---------------------------------------------------------------- BCE
ATRIBUTOS_SDMX = [
    "KEY", "FREQ", "EXR_TYPE", "EXR_SUFFIX", "OBS_STATUS", "OBS_CONF", "OBS_PRE_BREAK", "OBS_COM",
    "TIME_FORMAT", "BREAKS", "COLLECTION", "COMPILING_ORG", "DISS_ORG", "DOM_SER_IDS", "PUBL_ECB",
    "PUBL_MU", "PUBL_PUBLIC", "UNIT_INDEX_BASE", "COMPILATION", "COVERAGE", "DECIMALS", "NAT_TITLE",
    "SOURCE_AGENCY", "SOURCE_PUB", "TITLE", "TITLE_COMPL", "UNIT", "UNIT_MULT",
]


@dp.temporary_view(name="v_bce_exr")
@dp.expect_or_drop("chave_completa", "moeda IS NOT NULL AND data IS NOT NULL")
@dp.expect("taxa_positiva", "taxa_por_eur > 0")
def v_bce_exr():
    return bronze("bce_exr").select(
        pj("CURRENCY").alias("moeda"),
        pj("CURRENCY_DENOM").alias("moeda_base"),
        F.to_date(F.try_to_timestamp(pj("TIME_PERIOD"), F.lit("yyyy-MM-dd"))).alias("data"),
        F.expr("try_cast(try_variant_get(pv, '$.OBS_VALUE', 'string') AS DOUBLE)").alias("taxa_por_eur"),
        (F.lit(1.0) / F.expr("try_cast(try_variant_get(pv, '$.OBS_VALUE', 'string') AS DOUBLE)")).alias("eur_por_unidade"),
        *[pj(a).alias(a.lower()) for a in ATRIBUTOS_SDMX],
        F.col("payload").alias("registo_original"),
        *LINHAGEM,
    )


upsert("bce_exr", "v_bce_exr", ["moeda", "moeda_base", "data"],
       "BCE: taxa de referência diária (unidades da moeda por 1 EUR), com todos os atributos SDMX.",
       cluster_by=["moeda", "data"])
