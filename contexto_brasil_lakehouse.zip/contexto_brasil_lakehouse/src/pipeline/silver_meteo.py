"""
SILVER — meteorologia (Open-Meteo).

* Arquivo (diário e horário): histórico consolidado, uma linha por município e dia/hora.
* Previsão (diária e horária): fica a emissão mais recente para cada instante (SCD tipo 1).
  O histórico de TODAS as emissões continua no bronze, se quiser medir a qualidade das previsões.
* Atual: última observação por município.

As variáveis abaixo viram colunas tipadas. Qualquer outra que a ingestão traga continua disponível
na coluna `registo_original` (JSON) sem alterar este ficheiro.
"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F

CAT = spark.conf.get("contexto.catalog")
LINHAGEM = ["ingestao_ts", "_lote_id", "_linha", "ficheiro", "_url"]
SEQ = F.struct("ingestao_ts", "_linha")

VARIAVEIS_DIARIAS = [
    "weather_code", "temperature_2m_max", "temperature_2m_min", "temperature_2m_mean",
    "apparent_temperature_max", "apparent_temperature_min", "apparent_temperature_mean",
    "sunrise", "sunset", "daylight_duration", "sunshine_duration", "uv_index_max",
    "precipitation_sum", "rain_sum", "showers_sum", "snowfall_sum", "precipitation_hours",
    "precipitation_probability_max", "wind_speed_10m_max", "wind_gusts_10m_max",
    "wind_direction_10m_dominant", "shortwave_radiation_sum", "et0_fao_evapotranspiration",
]

VARIAVEIS_HORARIAS = [
    "temperature_2m", "relative_humidity_2m", "dew_point_2m", "apparent_temperature",
    "precipitation_probability", "precipitation", "rain", "showers", "snowfall", "snow_depth", "weather_code",
    "pressure_msl", "surface_pressure", "cloud_cover", "cloud_cover_low", "cloud_cover_mid", "cloud_cover_high",
    "visibility", "evapotranspiration", "et0_fao_evapotranspiration", "vapour_pressure_deficit",
    "wind_speed_10m", "wind_speed_100m", "wind_direction_10m", "wind_direction_100m", "wind_gusts_10m",
    "uv_index", "is_day", "sunshine_duration", "shortwave_radiation", "direct_radiation", "diffuse_radiation",
    "direct_normal_irradiance", "soil_temperature_0_to_7cm", "soil_moisture_0_to_7cm",
]

VARIAVEIS_ATUAIS = [
    "temperature_2m", "relative_humidity_2m", "apparent_temperature", "is_day", "precipitation", "rain",
    "showers", "snowfall", "weather_code", "cloud_cover", "pressure_msl", "surface_pressure",
    "wind_speed_10m", "wind_direction_10m", "wind_gusts_10m", "interval",
]

INTEIRAS = {"weather_code", "is_day", "interval", "precipitation_probability", "precipitation_probability_max"}
INSTANTES = {"sunrise", "sunset"}


def bronze(tabela):
    return spark.readStream.table(f"{CAT}.bronze.{tabela}").withColumn("pv", F.expr("parse_json(payload)"))


def pj(campo, tipo="string"):
    return F.expr(f"try_variant_get(pv, '$.{campo}', '{tipo}')")


def ts_local(col):
    """'2026-11-03T14:00' ou '2026-11-03' (hora local do município) -> TIMESTAMP_NTZ, sem conversões de fuso."""
    return F.expr(f"try_cast({col} AS TIMESTAMP_NTZ)")


def colunas_variaveis(variaveis):
    cols = []
    for v in variaveis:
        if v in INSTANTES:
            cols.append(ts_local(f"try_variant_get(pv, '$.{v}', 'string')").alias(v))
        elif v in INTEIRAS:
            cols.append(pj(v, "int").alias(v))
        else:
            cols.append(pj(v, "double").alias(v))
    return cols


def contexto_local():
    return [
        F.col("contexto").getItem("cod_municipio").cast("bigint").alias("cod_municipio"),
        F.col("contexto").getItem("municipio").alias("municipio"),
        F.col("contexto").getItem("sigla_uf").alias("sigla_uf"),
        F.col("contexto").getItem("modelo").alias("modelo"),
        pj("grelha_latitude", "double").alias("grelha_latitude"),
        pj("grelha_longitude", "double").alias("grelha_longitude"),
        pj("elevacao", "double").alias("elevacao_m"),
        pj("timezone").alias("timezone"),
        pj("utc_offset_segundos", "int").alias("utc_offset_segundos"),
    ]


def upsert(tabela, view, chaves, comentario, cluster_by=None):
    dp.create_streaming_table(
        name=f"{CAT}.silver.{tabela}",
        comment=comentario,
        table_properties={"quality": "silver", "delta.enableChangeDataFeed": "true"},
        cluster_by=cluster_by,
    )
    dp.create_auto_cdc_flow(
        target=f"{CAT}.silver.{tabela}", source=view, keys=chaves, sequence_by=SEQ,
        stored_as_scd_type=1, name=f"cdc_{tabela}",
    )


# ---------------------------------------------------------------- diário (arquivo e previsão)
def criar_diario(tabela_bronze, tabela_silver, comentario, origem):
    view = f"v_{tabela_silver}"

    @dp.temporary_view(name=view)
    @dp.expect_or_drop("chave_completa", "cod_municipio IS NOT NULL AND data IS NOT NULL")
    @dp.expect("temperaturas_coerentes", "temperature_2m_max IS NULL OR temperature_2m_min IS NULL "
                                         "OR temperature_2m_max >= temperature_2m_min")
    @dp.expect("temperatura_plausivel", "temperature_2m_max IS NULL OR temperature_2m_max BETWEEN -20 AND 55")
    def _v():
        return (
            bronze(tabela_bronze)
            .select(
                *contexto_local(),
                F.to_date(ts_local("try_variant_get(pv, '$.time', 'string')")).alias("data"),
                *colunas_variaveis(VARIAVEIS_DIARIAS),
                F.lit(origem).alias("origem"),
                F.col("ingestao_ts").alias("emitido_em"),
                F.col("payload").alias("registo_original"),
                *LINHAGEM,
            )
            .withColumn("horas_sol", F.col("sunshine_duration") / 3600)
            .withColumn("horas_luz", F.col("daylight_duration") / 3600)
            .withColumn("amplitude_termica", F.col("temperature_2m_max") - F.col("temperature_2m_min"))
        )

    upsert(tabela_silver, view, ["cod_municipio", "data"], comentario, cluster_by=["cod_municipio", "data"])


criar_diario("meteo_arquivo_diario", "meteo_arquivo_diario",
             "Meteorologia diária histórica por município (Open-Meteo, reanálise ERA5).", "arquivo")
criar_diario("meteo_previsao_diaria", "meteo_previsao_diaria",
             "Meteorologia diária: últimos 7 dias + 16 dias de previsão; fica a emissão mais recente.", "previsao")


# ---------------------------------------------------------------- horário (arquivo e previsão)
def criar_horario(tabela_bronze, tabela_silver, comentario, origem):
    view = f"v_{tabela_silver}"

    @dp.temporary_view(name=view)
    @dp.expect_or_drop("chave_completa", "cod_municipio IS NOT NULL AND data_hora IS NOT NULL")
    @dp.expect("humidade_valida", "relative_humidity_2m IS NULL OR relative_humidity_2m BETWEEN 0 AND 100")
    def _v():
        return (
            bronze(tabela_bronze)
            .select(
                *contexto_local(),
                ts_local("try_variant_get(pv, '$.time', 'string')").alias("data_hora"),
                *colunas_variaveis(VARIAVEIS_HORARIAS),
                F.lit(origem).alias("origem"),
                F.col("ingestao_ts").alias("emitido_em"),
                F.col("payload").alias("registo_original"),
                *LINHAGEM,
            )
            .withColumn("data", F.to_date("data_hora"))
            .withColumn("hora", F.hour("data_hora"))
        )

    upsert(tabela_silver, view, ["cod_municipio", "data_hora"], comentario, cluster_by=["cod_municipio", "data"])


criar_horario("meteo_arquivo_horario", "meteo_arquivo_horario",
              "Meteorologia horária histórica por município (Open-Meteo, reanálise ERA5).", "arquivo")
criar_horario("meteo_previsao_horaria", "meteo_previsao_horaria",
              "Meteorologia horária: últimos 7 dias + 16 dias de previsão; fica a emissão mais recente.", "previsao")


# ---------------------------------------------------------------- condições atuais
@dp.temporary_view(name="v_meteo_atual")
@dp.expect_or_drop("chave_completa", "cod_municipio IS NOT NULL AND data_hora IS NOT NULL")
def v_meteo_atual():
    return bronze("meteo_atual").select(
        *contexto_local(),
        ts_local("try_variant_get(pv, '$.time', 'string')").alias("data_hora"),
        *colunas_variaveis(VARIAVEIS_ATUAIS),
        F.col("ingestao_ts").alias("obtido_em"),
        F.col("payload").alias("registo_original"),
        *LINHAGEM,
    )


upsert("meteo_atual", "v_meteo_atual", ["cod_municipio"],
       "Condições meteorológicas atuais: a observação mais recente de cada município.")


# ---------------------------------------------------------------- locais e unidades
@dp.temporary_view(name="v_meteo_locais")
@dp.expect_or_drop("coordenadas", "cod_municipio IS NOT NULL AND latitude IS NOT NULL AND longitude IS NOT NULL")
def v_meteo_locais():
    return bronze("meteo_locais").select(
        pj("cod_municipio", "bigint").alias("cod_municipio"),
        pj("municipio").alias("municipio"),
        pj("sigla_uf").alias("sigla_uf"),
        pj("latitude", "double").alias("latitude"),
        pj("longitude", "double").alias("longitude"),
        pj("area_km2", "double").alias("area_km2"),
        pj("fonte_coordenadas").alias("fonte_coordenadas"),
        *LINHAGEM,
    )


upsert("meteo_locais", "v_meteo_locais", ["cod_municipio"],
       "Municípios com meteorologia: coordenadas (centroide IBGE) e área.")


@dp.temporary_view(name="v_meteo_unidades")
@dp.expect_or_drop("variavel", "variavel IS NOT NULL")
def v_meteo_unidades():
    return bronze("meteo_unidades").select(
        pj("endpoint").alias("endpoint"),
        pj("bloco").alias("bloco"),
        pj("variavel").alias("variavel"),
        pj("unidade").alias("unidade"),
        *LINHAGEM,
    )


upsert("meteo_unidades", "v_meteo_unidades", ["endpoint", "bloco", "variavel"],
       "Unidade de cada variável meteorológica, por endpoint e bloco.")
