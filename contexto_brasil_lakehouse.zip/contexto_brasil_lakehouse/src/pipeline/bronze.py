"""
BRONZE — registos brutos, tal como chegaram das APIs.

Uma streaming table por (fonte, dataset), alimentada pelo Auto Loader a partir da landing zone.
O schema é fixo (o envelope), e o registo da API fica intacto na coluna `payload` (texto JSON):
nada se perde, e uma mudança na API nunca parte o bronze. A interpretação é feita na silver.
"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F
from pyspark.sql.types import LongType, MapType, StringType, StructField, StructType

CAT = spark.conf.get("contexto.catalog")
LANDING = spark.conf.get("contexto.landing")

ENVELOPE = StructType([
    StructField("_fonte", StringType()),
    StructField("_dataset", StringType()),
    StructField("_url", StringType()),
    StructField("_ingestao_ts", StringType()),
    StructField("_lote_id", StringType()),
    StructField("_linha", LongType()),
    StructField("contexto", MapType(StringType(), StringType())),
    StructField("payload", StringType()),
])

# (fonte, dataset na landing, tabela bronze, descrição)
DATASETS = [
    ("bcb", "sgs", "bcb_sgs", "BCB SGS: séries de câmbio, inflação e juros"),
    ("bcb", "ptax_cotacoes", "bcb_ptax_cotacoes", "BCB PTAX: cotações de todos os boletins do dia"),
    ("bcb", "ptax_moedas", "bcb_ptax_moedas", "BCB PTAX: moedas disponíveis"),
    ("bce", "exr", "bce_exr", "BCE: taxas de referência do euro (todas as moedas, com atributos SDMX)"),
    ("feriados", "brasilapi", "feriados_brasilapi", "Feriados nacionais (BrasilAPI)"),
    ("feriados", "nager", "feriados_nager", "Feriados do Brasil (Nager.Date), incluindo regionais"),
    ("ibge", "municipios", "ibge_municipios", "IBGE: municípios e hierarquia territorial"),
    ("ibge", "estados", "ibge_estados", "IBGE: unidades da federação"),
    ("ibge", "populacao_estimada", "ibge_populacao_estimada", "IBGE: estimativas anuais de população (SIDRA 6579)"),
    ("ibge", "censo_2022", "ibge_censo_2022", "IBGE: população residente no Censo 2022 (SIDRA 4709)"),
    ("meteo", "locais", "meteo_locais", "Coordenadas dos municípios usados na meteorologia"),
    ("meteo", "unidades", "meteo_unidades", "Open-Meteo: unidades de cada variável"),
    ("meteo", "arquivo_diario", "meteo_arquivo_diario", "Open-Meteo: histórico diário (ERA5)"),
    ("meteo", "arquivo_horario", "meteo_arquivo_horario", "Open-Meteo: histórico horário (ERA5)"),
    ("meteo", "previsao_diaria", "meteo_previsao_diaria", "Open-Meteo: previsão diária (todas as emissões)"),
    ("meteo", "previsao_horaria", "meteo_previsao_horaria", "Open-Meteo: previsão horária (todas as emissões)"),
    ("meteo", "atual", "meteo_atual", "Open-Meteo: condições atuais"),
]


def criar_bronze(fonte, dataset, tabela, descricao):
    caminho = f"{LANDING}/{fonte}/{dataset}"

    @dp.table(
        name=f"{CAT}.bronze.{tabela}",
        comment=f"{descricao}. Origem: {caminho}",
        table_properties={"quality": "bronze", "delta.enableChangeDataFeed": "true"},
    )
    def _bronze():
        return (
            spark.readStream.format("cloudFiles")
            .option("cloudFiles.format", "json")
            .option("pathGlobFilter", "*.json")  # ignora os .tmp em escrita
            .schema(ENVELOPE)
            .load(caminho)
            .withColumn("ingestao_ts", F.to_timestamp("_ingestao_ts"))
            .withColumn("ficheiro", F.col("_metadata.file_path"))
            .withColumn("ficheiro_modificado_em", F.col("_metadata.file_modification_time"))
            .withColumn("bronze_carregado_em", F.current_timestamp())
        )

    return _bronze


for _fonte, _dataset, _tabela, _descricao in DATASETS:
    criar_bronze(_fonte, _dataset, _tabela, _descricao)
