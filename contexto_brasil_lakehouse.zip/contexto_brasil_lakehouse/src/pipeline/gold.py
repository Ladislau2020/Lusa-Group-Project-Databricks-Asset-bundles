"""
GOLD — dimensões e factos prontos para Power BI / Fabric / análise.

Materialized views: o pipeline recalcula-as de forma incremental quando a silver muda
(em serverless, com refresh incremental sempre que possível).
"""
from pyspark import pipelines as dp
from pyspark.sql import functions as F

CAT = spark.conf.get("contexto.catalog")
CAL_INICIO = spark.conf.get("contexto.calendario_inicio", "2010-01-01")
CAL_FIM = spark.conf.get("contexto.calendario_fim", "2030-12-31")
S = f"{CAT}.silver"
G = f"{CAT}.gold"

CAPITAIS = [1100205, 1200401, 1302603, 1400100, 1501402, 1600303, 1721000, 2111300, 2211001, 2304400,
            2408102, 2507507, 2611606, 2704302, 2800308, 2927408, 3106200, 3205309, 3304557, 3550308,
            4106902, 4205407, 4314902, 5002704, 5103403, 5208707, 5300108]

HOJE_BR = "to_date(from_utc_timestamp(current_timestamp(), 'America/Sao_Paulo'))"


def mv(nome, comentario):
    return dp.materialized_view(name=f"{G}.{nome}", comment=comentario, table_properties={"quality": "gold"})


# ---------------------------------------------------------------- dim_calendario
@mv("dim_calendario", "Calendário diário com feriados nacionais e regionais, dias úteis, pontes e estações do ano.")
def dim_calendario():
    return spark.sql(f"""
    WITH dias AS (
      SELECT explode(sequence(DATE'{CAL_INICIO}', DATE'{CAL_FIM}', INTERVAL 1 DAY)) AS data
    ),
    nacionais AS (
      SELECT data,
             concat_ws(' / ', collect_set(nome)) AS nome_feriado,
             max(tipo = 'national') AS e_feriado_nacional,
             max(tipo <> 'national') AS e_ponto_facultativo,
             concat_ws(' / ', collect_set(tipo_descricao)) AS tipo_feriado
      FROM {S}.feriados_brasilapi GROUP BY data
    ),
    nager AS (
      SELECT data,
             max(nacional) AS nager_nacional,
             concat_ws(' / ', collect_set(nome_en)) AS nome_feriado_en,
             max(data_fixa) AS feriado_data_fixa,
             array_sort(array_distinct(flatten(collect_list(CASE WHEN NOT nacional THEN ufs END)))) AS ufs_feriado_regional,
             concat_ws(' / ', collect_set(CASE WHEN NOT nacional THEN nome_local END)) AS nome_feriado_regional
      FROM {S}.feriados_nager GROUP BY data
    ),
    base AS (
      SELECT d.data,
             year(d.data) AS ano,
             CASE WHEN month(d.data) <= 6 THEN 1 ELSE 2 END AS semestre,
             quarter(d.data) AS trimestre,
             month(d.data) AS mes,
             element_at(array('janeiro','fevereiro','março','abril','maio','junho','julho','agosto',
                              'setembro','outubro','novembro','dezembro'), month(d.data)) AS nome_mes,
             date_format(d.data, 'yyyy-MM') AS ano_mes,
             trunc(d.data, 'MM') AS inicio_mes,
             last_day(d.data) AS fim_mes,
             day(d.data) AS dia,
             dayofyear(d.data) AS dia_do_ano,
             weekofyear(d.data) AS semana_iso,
             weekday(d.data) + 1 AS dia_semana_num,
             element_at(array('segunda-feira','terça-feira','quarta-feira','quinta-feira','sexta-feira',
                              'sábado','domingo'), weekday(d.data) + 1) AS nome_dia_semana,
             weekday(d.data) >= 5 AS e_fim_de_semana,
             coalesce(n.e_feriado_nacional, false) AS e_feriado_nacional,
             coalesce(n.e_ponto_facultativo, false) AS e_ponto_facultativo,
             n.nome_feriado, n.tipo_feriado, g.nome_feriado_en, g.feriado_data_fixa,
             coalesce(g.ufs_feriado_regional, array()) AS ufs_feriado_regional,
             nullif(g.nome_feriado_regional, '') AS nome_feriado_regional,
             -- estações do ano no hemisfério sul (aproximação por solstícios/equinócios)
             CASE WHEN date_format(d.data, 'MMdd') >= '1221' OR date_format(d.data, 'MMdd') < '0320' THEN 'verão'
                  WHEN date_format(d.data, 'MMdd') < '0621' THEN 'outono'
                  WHEN date_format(d.data, 'MMdd') < '0923' THEN 'inverno'
                  ELSE 'primavera' END AS estacao_ano
      FROM dias d
      LEFT JOIN nacionais n USING (data)
      LEFT JOIN nager g USING (data)
    ),
    uteis AS (
      SELECT *,
             NOT e_fim_de_semana AND NOT e_feriado_nacional AS e_dia_util
      FROM base
    ),
    vizinhos AS (
      SELECT *,
             lag(e_dia_util) OVER (ORDER BY data) AS ontem_util,
             lead(e_dia_util) OVER (ORDER BY data) AS amanha_util,
             lag(e_feriado_nacional) OVER (ORDER BY data) AS ontem_feriado,
             lead(e_feriado_nacional) OVER (ORDER BY data) AS amanha_feriado
      FROM uteis
    )
    SELECT *,
           -- ponte: dia útil isolado entre um feriado e o fim de semana (ex.: sexta depois de feriado à quinta)
           e_dia_util AND ((ontem_feriado AND NOT amanha_util) OR (amanha_feriado AND NOT ontem_util)) AS e_ponte,
           sum(CASE WHEN e_dia_util THEN 1 ELSE 0 END) OVER (PARTITION BY inicio_mes ORDER BY data) AS dia_util_do_mes,
           sum(CASE WHEN e_dia_util THEN 1 ELSE 0 END) OVER (PARTITION BY inicio_mes) AS dias_uteis_no_mes,
           data = max(CASE WHEN e_dia_util THEN data END) OVER (PARTITION BY inicio_mes) AS e_ultimo_dia_util_mes
    FROM vizinhos
    """).drop("ontem_util", "amanha_util", "ontem_feriado", "amanha_feriado")


# ---------------------------------------------------------------- câmbio PTAX diário
@mv("fato_cambio_ptax_diario",
    "Câmbio oficial PTAX (fecho) por dia e moeda, comparado com a taxa cruzada do BCE, com variações e médias móveis.")
def fato_cambio_ptax_diario():
    return spark.sql(f"""
    WITH boletins AS (
      SELECT *, row_number() OVER (PARTITION BY moeda, data_cotacao ORDER BY data_hora_cotacao DESC) AS rn_fecho,
                row_number() OVER (PARTITION BY moeda, data_cotacao ORDER BY data_hora_cotacao ASC) AS rn_abertura,
                count(*) OVER (PARTITION BY moeda, data_cotacao) AS boletins_no_dia
      FROM {S}.bcb_ptax_cotacoes
    ),
    fecho AS (
      SELECT moeda, data_cotacao AS data, data_hora_cotacao AS hora_fecho, tipo_boletim,
             cotacao_compra, cotacao_venda, cotacao_media, spread_pct, paridade_compra, paridade_venda,
             boletins_no_dia
      FROM boletins WHERE e_fechamento AND rn_fecho = 1
    ),
    abertura AS (
      SELECT moeda, data_cotacao AS data, cotacao_venda AS abertura_venda
      FROM boletins WHERE rn_abertura = 1
    ),
    bce_brl AS (SELECT data, taxa_por_eur AS bce_brl_por_eur FROM {S}.bce_exr WHERE moeda = 'BRL'),
    bce AS (SELECT data, moeda, taxa_por_eur AS bce_moeda_por_eur FROM {S}.bce_exr),
    juntos AS (
      SELECT f.*, a.abertura_venda, b.bce_brl_por_eur,
             CASE WHEN f.moeda = 'EUR' THEN b.bce_brl_por_eur ELSE b.bce_brl_por_eur / x.bce_moeda_por_eur END
               AS bce_brl_por_unidade,
             f.cotacao_venda / lag(f.cotacao_venda) OVER (PARTITION BY f.moeda ORDER BY f.data) - 1 AS retorno_dia
      FROM fecho f
      LEFT JOIN abertura a ON a.moeda = f.moeda AND a.data = f.data
      LEFT JOIN bce_brl b ON b.data = f.data
      LEFT JOIN bce x ON x.data = f.data AND x.moeda = f.moeda
    )
    SELECT j.data, j.moeda, m.nome AS moeda_nome, m.tipo_moeda,
           j.cotacao_compra AS ptax_compra, j.cotacao_venda AS ptax_venda, j.cotacao_media AS ptax_media,
           j.spread_pct, j.paridade_compra, j.paridade_venda, j.hora_fecho, j.boletins_no_dia,
           j.abertura_venda,
           (j.cotacao_venda / j.abertura_venda - 1) * 100 AS variacao_intradia_pct,
           j.retorno_dia * 100 AS variacao_dia_pct,
           avg(j.cotacao_venda) OVER (PARTITION BY j.moeda ORDER BY j.data ROWS BETWEEN 6 PRECEDING AND CURRENT ROW)
             AS media_movel_7d,
           avg(j.cotacao_venda) OVER (PARTITION BY j.moeda ORDER BY j.data ROWS BETWEEN 29 PRECEDING AND CURRENT ROW)
             AS media_movel_30d,
           stddev(j.retorno_dia) OVER (PARTITION BY j.moeda ORDER BY j.data ROWS BETWEEN 20 PRECEDING AND CURRENT ROW)
             * sqrt(252) * 100 AS volatilidade_21d_anualizada_pct,
           j.bce_brl_por_eur, j.bce_brl_por_unidade,
           (j.cotacao_media / j.bce_brl_por_unidade - 1) * 100 AS diferenca_ptax_vs_bce_pct,
           c.e_dia_util, c.e_feriado_nacional, c.nome_feriado
    FROM juntos j
    LEFT JOIN {S}.bcb_ptax_moedas m ON m.simbolo = j.moeda
    LEFT JOIN {G}.dim_calendario c ON c.data = j.data
    """)


# ---------------------------------------------------------------- câmbio BCE (todas as moedas)
@mv("fato_cambio_eur_diario",
    "Taxas de referência do BCE para todas as moedas, com conversão cruzada para BRL.")
def fato_cambio_eur_diario():
    return spark.sql(f"""
    WITH brl AS (SELECT data, taxa_por_eur AS brl_por_eur FROM {S}.bce_exr WHERE moeda = 'BRL')
    SELECT e.data, e.moeda, e.moeda_base, e.title AS descricao, e.taxa_por_eur, e.eur_por_unidade,
           b.brl_por_eur, b.brl_por_eur / e.taxa_por_eur AS brl_por_unidade_cruzado,
           (e.taxa_por_eur / lag(e.taxa_por_eur) OVER (PARTITION BY e.moeda ORDER BY e.data) - 1) * 100
             AS variacao_dia_pct,
           avg(e.taxa_por_eur) OVER (PARTITION BY e.moeda ORDER BY e.data ROWS BETWEEN 29 PRECEDING AND CURRENT ROW)
             AS media_movel_30d,
           e.obs_status, e.decimals, e.unit, e.unit_mult
    FROM {S}.bce_exr e
    LEFT JOIN brl b ON b.data = e.data
    """)


# ---------------------------------------------------------------- indicadores mensais
@mv("fato_indicadores_mensal",
    "Indicadores BCB por mês: inflação com acumulados no ano e em 12 meses; séries diárias resumidas por mês.")
def fato_indicadores_mensal():
    return spark.sql(f"""
    WITH mensal AS (
      SELECT serie_codigo, serie_nome, categoria, unidade, periodicidade,
             trunc(data, 'MM') AS mes,
             avg(valor) AS valor_medio,
             max_by(valor, data) AS valor_fim_mes,
             min(valor) AS valor_minimo,
             max(valor) AS valor_maximo,
             count(valor) AS observacoes
      FROM {S}.bcb_sgs
      GROUP BY ALL
    ),
    calc AS (
      SELECT *,
             CASE WHEN unidade = '% a.m.' THEN valor_fim_mes END AS taxa_mes_pct,
             CASE WHEN unidade = '% a.m.' THEN
               (exp(sum(ln(1 + valor_fim_mes / 100)) OVER (PARTITION BY serie_codigo, year(mes) ORDER BY mes)) - 1) * 100
             END AS acumulado_ano_pct,
             CASE WHEN unidade = '% a.m.' AND
                       count(*) OVER (PARTITION BY serie_codigo ORDER BY mes ROWS BETWEEN 11 PRECEDING AND CURRENT ROW) = 12
                  THEN (exp(sum(ln(1 + valor_fim_mes / 100)) OVER (PARTITION BY serie_codigo ORDER BY mes
                                                                    ROWS BETWEEN 11 PRECEDING AND CURRENT ROW)) - 1) * 100
             END AS acumulado_12m_pct,
             CASE WHEN unidade <> '% a.m.' THEN
               (valor_fim_mes / lag(valor_fim_mes) OVER (PARTITION BY serie_codigo ORDER BY mes) - 1) * 100
             END AS variacao_mensal_pct
      FROM mensal
    )
    SELECT *, year(mes) AS ano, month(mes) AS mes_num, date_format(mes, 'yyyy-MM') AS ano_mes FROM calc
    """)


# ---------------------------------------------------------------- municípios e população
@mv("fato_populacao_municipio", "População por município e ano (estimativas anuais e Censo 2022), com variação anual.")
def fato_populacao_municipio():
    return spark.sql(f"""
    WITH todas AS (
      SELECT cod_municipio, ano, populacao, tipo_contagem, tabela_sidra FROM {S}.ibge_populacao_estimada
      UNION ALL
      SELECT cod_municipio, ano, populacao, tipo_contagem, tabela_sidra FROM {S}.ibge_censo_2022
    )
    SELECT *,
           populacao - lag(populacao) OVER w AS variacao_absoluta,
           (populacao / lag(populacao) OVER w - 1) * 100 AS variacao_pct
    FROM todas
    WINDOW w AS (PARTITION BY cod_municipio, tipo_contagem ORDER BY ano)
    """)


@mv("dim_municipio", "Municípios (versão atual) com hierarquia territorial, população mais recente, censo e coordenadas.")
def dim_municipio():
    capitais = ",".join(str(c) for c in CAPITAIS)
    return spark.sql(f"""
    WITH est AS (
      SELECT cod_municipio, max_by(populacao, ano) AS populacao_estimada, max(ano) AS ano_populacao_estimada
      FROM {S}.ibge_populacao_estimada WHERE populacao IS NOT NULL GROUP BY cod_municipio
    )
    SELECT m.cod_municipio, m.municipio, concat(m.municipio, ' - ', m.sigla_uf) AS municipio_uf,
           m.cod_uf, m.sigla_uf, m.uf, m.cod_regiao, m.sigla_regiao, m.regiao,
           m.cod_mesorregiao, m.mesorregiao, m.cod_microrregiao, m.microrregiao,
           m.cod_regiao_intermediaria, m.regiao_intermediaria, m.cod_regiao_imediata, m.regiao_imediata,
           m.cod_municipio IN ({capitais}) AS e_capital,
           e.populacao_estimada, e.ano_populacao_estimada,
           c.populacao AS populacao_censo_2022,
           CASE WHEN e.populacao_estimada >= 500000 THEN 'grande (500 mil+)'
                WHEN e.populacao_estimada >= 100000 THEN 'médio-grande (100–500 mil)'
                WHEN e.populacao_estimada >= 20000 THEN 'médio (20–100 mil)'
                WHEN e.populacao_estimada IS NOT NULL THEN 'pequeno (< 20 mil)' END AS porte,
           l.latitude, l.longitude, l.area_km2,
           e.populacao_estimada / l.area_km2 AS densidade_hab_km2,
           l.cod_municipio IS NOT NULL AS tem_meteorologia,
           m.`__START_AT` AS versao_desde
    FROM {S}.ibge_municipios m
    LEFT JOIN est e USING (cod_municipio)
    LEFT JOIN {S}.ibge_censo_2022 c ON c.cod_municipio = m.cod_municipio AND c.ano = 2022
    LEFT JOIN {S}.meteo_locais l ON l.cod_municipio = m.cod_municipio
    WHERE m.`__END_AT` IS NULL
    """)


# ---------------------------------------------------------------- meteorologia
CODIGOS_WMO = [
    (0, "Céu limpo", "limpo"), (1, "Predominantemente limpo", "limpo"), (2, "Parcialmente nublado", "nublado"),
    (3, "Nublado", "nublado"), (45, "Nevoeiro", "nevoeiro"), (48, "Nevoeiro com geada", "nevoeiro"),
    (51, "Chuvisco fraco", "chuvisco"), (53, "Chuvisco moderado", "chuvisco"), (55, "Chuvisco intenso", "chuvisco"),
    (56, "Chuvisco gelado fraco", "chuvisco"), (57, "Chuvisco gelado intenso", "chuvisco"),
    (61, "Chuva fraca", "chuva"), (63, "Chuva moderada", "chuva"), (65, "Chuva forte", "chuva"),
    (66, "Chuva gelada fraca", "chuva"), (67, "Chuva gelada forte", "chuva"),
    (71, "Neve fraca", "neve"), (73, "Neve moderada", "neve"), (75, "Neve forte", "neve"), (77, "Grãos de neve", "neve"),
    (80, "Aguaceiros fracos", "aguaceiros"), (81, "Aguaceiros moderados", "aguaceiros"),
    (82, "Aguaceiros violentos", "aguaceiros"), (85, "Aguaceiros de neve fracos", "neve"),
    (86, "Aguaceiros de neve fortes", "neve"), (95, "Trovoada", "trovoada"),
    (96, "Trovoada com granizo fraco", "trovoada"), (99, "Trovoada com granizo forte", "trovoada"),
]


@mv("dim_condicao_tempo", "Códigos de tempo WMO usados pela Open-Meteo, com descrição e grupo.")
def dim_condicao_tempo():
    return spark.createDataFrame(CODIGOS_WMO, "weather_code INT, condicao STRING, grupo_condicao STRING")


@mv("fato_meteo_diario",
    "Meteorologia diária contínua por município: histórico (arquivo), últimos dias observados e previsão a 16 dias.")
def fato_meteo_diario():
    arquivo = spark.read.table(f"{S}.meteo_arquivo_diario")
    previsao = spark.read.table(f"{S}.meteo_previsao_diaria")
    # A previsão só preenche as datas que o arquivo ainda não tem (o arquivo tem ~5 dias de atraso)
    previsao = previsao.join(arquivo.select("cod_municipio", "data"), ["cod_municipio", "data"], "left_anti")
    linhagem = ["ingestao_ts", "_lote_id", "_linha", "ficheiro", "_url", "registo_original"]
    base = arquivo.drop(*linhagem).unionByName(previsao.drop(*linhagem), allowMissingColumns=True)

    wmo = spark.read.table(f"{G}.dim_condicao_tempo")
    cal = spark.read.table(f"{G}.dim_calendario").select(
        "data", "e_dia_util", "e_feriado_nacional", "nome_feriado", "e_fim_de_semana", "estacao_ano",
        "ufs_feriado_regional",
    )
    return (
        base.join(wmo, "weather_code", "left")
        .join(cal, "data", "left")
        .withColumn("tipo_registo", F.expr(f"""
            CASE WHEN origem = 'arquivo' THEN 'histórico'
                 WHEN data < {HOJE_BR} THEN 'observado recente'
                 WHEN data = {HOJE_BR} THEN 'hoje'
                 ELSE 'previsão' END"""))
        .withColumn("e_dia_chuvoso", F.col("precipitation_sum") >= 1)
        .withColumn("classe_chuva", F.expr("""
            CASE WHEN precipitation_sum IS NULL THEN NULL
                 WHEN precipitation_sum < 1 THEN 'sem chuva'
                 WHEN precipitation_sum < 10 THEN 'chuva fraca'
                 WHEN precipitation_sum < 30 THEN 'chuva moderada'
                 WHEN precipitation_sum < 50 THEN 'chuva forte'
                 ELSE 'chuva muito forte' END"""))
        .withColumn("classe_temperatura", F.expr("""
            CASE WHEN temperature_2m_max >= 35 THEN 'muito quente'
                 WHEN temperature_2m_max >= 30 THEN 'quente'
                 WHEN temperature_2m_max >= 20 THEN 'ameno'
                 WHEN temperature_2m_max IS NOT NULL THEN 'frio' END"""))
        .withColumn("e_feriado_estadual", F.expr("coalesce(array_contains(ufs_feriado_regional, sigla_uf), false)"))
        .drop("ufs_feriado_regional")
    )


@mv("meteo_condicao_atual", "Condições meteorológicas atuais por município (última observação).")
def meteo_condicao_atual():
    return spark.sql(f"""
    SELECT a.cod_municipio, a.municipio, a.sigla_uf, a.data_hora AS hora_local, a.obtido_em,
           a.temperature_2m, a.apparent_temperature, a.relative_humidity_2m, a.precipitation, a.rain,
           a.cloud_cover, a.pressure_msl, a.wind_speed_10m, a.wind_direction_10m, a.wind_gusts_10m,
           a.is_day = 1 AS e_dia, a.weather_code, w.condicao, w.grupo_condicao,
           a.grelha_latitude AS latitude, a.grelha_longitude AS longitude, a.timezone
    FROM {S}.meteo_atual a
    LEFT JOIN {G}.dim_condicao_tempo w ON w.weather_code = a.weather_code
    """)
